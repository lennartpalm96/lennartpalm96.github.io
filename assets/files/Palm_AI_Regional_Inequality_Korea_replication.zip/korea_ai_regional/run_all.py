"""Reproduce all figures and tables for
"AI Adoption as a New Frontier of Regional Inequality in Korea", plus province-level additional results.

Usage (from this folder):   python run_all.py
Options:                    python run_all.py --force-prepare   (re-read the survey microdata CSV)
Outputs:
  output/main/                         paper figures (fig1-fig6) and the tables behind them (macro regions)
  output/crosswalk/                    KSCO-8 2-digit -> SOC major crosswalk + implied SOC employment
  output/additional/provinces_17/      all results for the 17 provinces (no aggregation)
  output/additional/provinces_capital_area/   15 units, Seoul+Incheon+Gyeonggi merged into the Capital Area
  output/additional/data_checks/       inferred sample sizes, Computer & Math breakdown
"""
import os, sys, shutil, subprocess, time

ROOT = os.path.dirname(os.path.abspath(__file__))
SRC = os.path.join(ROOT, 'src')
RAW = os.path.join(ROOT, 'data', 'raw')
INTERIM = os.path.join(ROOT, 'data', 'interim')
OUT = os.path.join(ROOT, 'output')
MAIN = os.path.join(OUT, 'main')
XW_DIR = os.path.join(OUT, 'crosswalk')
P17 = os.path.join(OUT, 'additional', 'provinces_17')
P15 = os.path.join(OUT, 'additional', 'provinces_capital_area')
CHK = os.path.join(OUT, 'additional', 'data_checks')
for d in (INTERIM, MAIN, XW_DIR, P17, P15, CHK):
    os.makedirs(d, exist_ok=True)

AEI_DIR = os.path.join(RAW, 'aei')
AEI = os.path.join(AEI_DIR, 'aei_claude_ai_2026-06-26.csv')
RES_CSV = os.path.join(RAW, 'res', 'res_2025h2_microdata.csv')
RES_BOOK = os.path.join(RAW, 'res', 'res_2025h2_codebook.xlsx')
ENR = os.path.join(RAW, 'kedi', 'Korea_2025_Student_Enrollment.csv')
GRDP = os.path.join(RAW, 'kosis', 'grdp_nominal_real_2000_2024.xlsx')
POP = os.path.join(RAW, 'kosis', 'population_2000_2025.xlsx')
GEO = os.path.join(RAW, 'geo', 'skorea-provinces-2018-geo.json')
MICRO = os.path.join(INTERIM, 'micro.pkl')
XW = os.path.join(XW_DIR, 'ksco8_2d_to_soc_major.csv')


def run(script, *args):
    t = time.time()
    print(f'\n>> {script} {" ".join(os.path.relpath(a, ROOT) if os.path.isabs(str(a)) else str(a) for a in args)}', flush=True)
    r = subprocess.run([sys.executable, os.path.join(SRC, script), *map(str, args)], cwd=SRC)
    if r.returncode != 0:
        sys.exit(f'!! {script} failed (exit {r.returncode})')
    print(f'   done in {time.time() - t:.0f}s', flush=True)


if __name__ == '__main__':
    t0 = time.time()
    # 0. survey microdata -> pickle (once)
    if not os.path.exists(RES_CSV) and not os.path.exists(MICRO):
        sys.exit('!! Survey microdata not found: data/raw/res/res_2025h2_microdata.csv\n'
                 '   Download the Regional Employment Survey, 2nd half 2025, from MDIS (https://mdis.kostat.go.kr);\n'
                 '   see data/raw/res/DOWNLOAD_MICRODATA.md.')
    if '--force-prepare' in sys.argv or not os.path.exists(MICRO):
        run('00_prepare.py', RES_CSV, INTERIM)

    # 1. occupation crosswalk
    run('build_crosswalk.py', INTERIM, RES_BOOK, XW_DIR)

    # 2. paper: GRDP / population (Figure 1)
    run('sma_grdp_analysis.py', GRDP, MAIN, POP)

    # 3. paper: macro-region figures (Figures 2-6) + sophistication; additional: 15-unit and 17-province versions
    for mode, out in (('macro', MAIN), ('province', P15), ('province17', P17)):
        run('make_figures.py', mode, AEI, MICRO, XW, ENR, out)
        tag = {'macro': 'macro', 'province': 'provinces', 'province17': 'provinces17'}[mode]
        run('sophistication.py', mode, AEI, os.path.join(out, f'{tag}_figure_data.xlsx'), out)

    # 3b. maps of work use per worker: macro regions (paper Figure 2); provinces with the Capital Area merged (additional)
    run('korea_map.py', 'macro', GEO, os.path.join(MAIN, 'macro_figure_data.xlsx'), os.path.join(MAIN, 'macro_map_work_usage_per_worker.png'))
    run('korea_map.py', 'province', GEO, os.path.join(P15, 'provinces_figure_data.xlsx'), os.path.join(P15, 'provinces_map_work_usage_per_worker.png'))

    # 4. additional province-level analyses
    run('usage_by_region_occupation.py', AEI_DIR, INTERIM, XW, os.path.join(P17, 'usage_region_x_occupation_17_provinces.xlsx'))
    run('usage_by_use_case.py', AEI_DIR, INTERIM, os.path.join(P17, 'usage_by_use_case_17_provinces.csv'))
    run('student_intensity.py', AEI_DIR, ENR, os.path.join(P17, 'coursework_per_student_17_provinces.xlsx'))
    cap_xlsx = os.path.join(P15, 'capital_area_all_results.xlsx')
    run('capital_area_analysis.py', AEI_DIR, INTERIM, XW, cap_xlsx)
    run('regional_wage_premia.py', INTERIM, XW, cap_xlsx, os.path.join(P15, 'regional_wage_premia.xlsx'))
    run('unevenness_gender.py', AEI_DIR, INTERIM, XW, os.path.join(P15, 'unevenness_occupation_gender.xlsx'))

    # 5. data checks
    run('inferred_sample_sizes.py', AEI, CHK)
    run('cm_breakdown.py', AEI, CHK)

    # 6. paper figure copies with their numbers in the text
    figs = {'fig1_sma_share_grdp_population.png': 'sma_grdp_share_2000_2024.png',
            'fig2_map_work_use_per_worker.png': 'macro_map_work_usage_per_worker.png',
            'fig3_occupation_adjusted_usage.png': 'macro_2_usage_unadjusted_vs_occupation_adjusted.png',
            'fig4_gaps_wage_education_ai.png': 'macro_4_gaps_vs_reference.png',
            'fig5_coursework_per_student.png': 'macro_5_coursework_per_student.png',
            'fig6_within_occupation_usage.png': 'macro_3_within_occupation_intensity.png'}
    os.makedirs(os.path.join(MAIN, 'paper_figures'), exist_ok=True)
    for new, old in figs.items():
        shutil.copy(os.path.join(MAIN, old), os.path.join(MAIN, 'paper_figures', new))
    print(f'\nAll done in {time.time() - t0:.0f}s. Paper figures: output/main/paper_figures/')
