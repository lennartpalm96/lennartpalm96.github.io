# Regional Employment Survey microdata: download required

The survey microdata are **not included** in this package. They are distributed by Statistics Korea through
MDIS (Microdata Integrated Service), whose terms do not allow redistribution. The codebook in this folder
(`res_2025h2_codebook.xlsx`) is included so the variables and codes can be checked.

## What to download

- **Survey:** Regional Employment Survey (지역별고용조사), second half 2025 (reference month October 2025)
- **Source:** MDIS, https://mdis.kostat.go.kr (free account required)
- **Version:** C-type microdata (the full person-level file with all 17 provinces), as CSV
- **Size:** about 404,000 rows × 57 columns, about 48 MB; CP949-encoded

## Where to put it

Save the CSV as

```
data/raw/res/res_2025h2_microdata.csv
```

Then run `python run_all.py` from the package folder. The first run converts it to `data/interim/micro.pkl`.
`run_all.py` stops with a message pointing here if the file is missing.

## Variables used

| Variable | Use |
|---|---|
| `경제활동구분코드` | employed (= 1) |
| `사업체직장소재지_행정구역코드` | workplace province (region of employment) |
| `2자리_행정구역시도코드` | residence province (residence-based benchmark) |
| `2자리_8차직업중분류코드` | occupation, KSCO-8 two-digit |
| `2자리_11차산업중분류코드` | industry, KSIC-11 two-digit (wage controls) |
| `시도가중값` | survey weight |
| `가구단위일련번호` | household ID (clustered standard errors) |
| `최근3개월_월평균급여`, `조사대상주간_주업근무시간수` | hourly wage |
| `현직장종사상지위코드` | employment status (wage earners = 1, 2) |
| `학력코드`, `교육정도_수학구분코드` | education, university degree share |
| `만연령`, `성별코드`, `혼인상태코드` | age, sex, marital status |
| `조사대상주간_직장시작연월`, `직장종사자규모코드`, `고용계약기간정함여부` | tenure, firm size, fixed-term contract |

If MDIS delivers a later revision of the file with renamed columns, adjust the names in `src/` accordingly.
