# South Korean student enrollment by province and education level, 2025

`Korea_2025_Student_Enrollment.csv` counts enrollments as of **1 April 2025**. It has one row for each of the 17 first-level administrative regions (시도) and a final national total. When summing across regions, exclude the row where `province == "South Korea"` to avoid counting every enrollment twice. All nine numeric fields are integer headcounts.

## Source workbooks

Both workbooks come from the Korean Educational Development Institute (KEDI) education statistics database. The 2026 date in the school workbook’s filename is its extraction date. Both files describe the same 2025 survey date.

| Source filename as supplied | Detail worksheet | Header row | First data row | Extracted |
|---|---|---:|---:|---|
| `2025년 유초중등 학교별 학년별 학생수 학급수 입학 졸업 교원 직원 면적_260206W.xlsx` | 학교별 주요통계 | 17 | 18 | 6 February 2026 |
| `2025년 고등 학교별 학과수 입학정원 지원 입학 학생 외국학생 졸업 교직원_250828H.xlsx` | 학교별 교육통계 | 14 | 15 | 28 August 2025 |

## Construction

1. Read the detail worksheets. Select school records with `조사기준일 = 20250401` and higher-education records with `연도 = 2025`. Use the institution or campus region in `시도` for both. Keep branch and campus records with reported students. The workbooks’ instructions for counting the number of institutions apply to a different measure.
2. For schools, group by `시도` and `학교급` and sum `학생수_총계_계`. This column already includes both sexes and all grades. Map school types to the first five CSV fields below.
3. For higher education, sum the active enrollment fields below. The source distinguishes active enrollment (재학생) from registration (재적생), which also includes students on leave and students deferring degree conferral. The graduate-school total already includes the master’s and doctoral counts, so count only its two components. Blank numeric count cells contribute zero to sums.
4. Combine the eight education-level counts by region. Sum the eight fields for each regional `total`, then sum each numeric field over the 17 regions for the national row.

| CSV field | Source category or calculation |
|---|---|
| `kindergarten` | 유치원 |
| `elementary` | 초등학교 |
| `middle` | 중학교 and 방송통신중학교 (broadcasting and correspondence middle schools) |
| `high` | 고등학교 and 방송통신고등학교 (broadcasting and correspondence high schools) |
| `other_schools` | 특수학교 (special schools), 각종학교 (miscellaneous schools), 고등기술학교 (higher technical schools), and 고등공민학교 (higher civic schools). Students in special classes within ordinary schools remain in their school’s own level. |
| `undergraduate` | Sum `재학생_전체_계` across all non-graduate `학제` categories. This includes junior colleges, polytechnics, open universities, and cyber universities as well as conventional universities. |
| `masters` | Sum `재학생_석사_계` across graduate-school records (일반대학원, 전문대학원, 특수대학원). |
| `doctoral` | Sum `재학생_박사_계` across the same graduate-school records. |
| `total` | Sum of the preceding eight fields. |

## Geography and interpretation

The `province` field uses the following English labels in source order.

| Korean | CSV label | Korean | CSV label |
|---|---|---|---|
| 서울 | Seoul | 강원 | Gangwon |
| 부산 | Busan | 충북 | Chungbuk |
| 대구 | Daegu | 충남 | Chungnam |
| 인천 | Incheon | 전북 | Jeonbuk |
| 광주 | Gwangju | 전남 | Jeonnam |
| 대전 | Daejeon | 경북 | Gyeongbuk |
| 울산 | Ulsan | 경남 | Gyeongnam |
| 세종 | Sejong | 제주 | Jeju |
| 경기 | Gyeonggi | | |

Geography follows the reporting institution, including for distance learners. These aggregates measure enrollments. Student residence and person-level identifiers are unavailable for deduplication across institutions.

## Validation

- The five school columns sum to **5,551,288** nationally. Their sum also matches the school workbook’s `요약정보` total in each of the 17 regions.
- The higher-education register contains **3,016,724** students. Registered counts were reconciled by institution type to the higher-education workbook’s `요약정보` sheet. Each detail row also satisfies registered = active + on leave + deferred degree conferral.
- Active higher-education enrollment is **2,354,941**, comprising **2,040,104 undergraduate**, **235,467 master’s**, and **79,370 doctoral** enrollments. Each graduate-school record’s active total equals its master’s plus doctoral counts.
- The combined national total is **7,906,229**. All CSV values were compared with the corresponding cells of the companion enrollment workbook, and the national sum was checked independently for each CSV column.
