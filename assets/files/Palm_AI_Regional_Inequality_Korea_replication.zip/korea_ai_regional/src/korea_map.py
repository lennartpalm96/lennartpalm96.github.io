"""Map of work use of Claude per worker (share of Korean work usage / share of employment, by workplace).

mode macro:    macro regions (paper Figure 2); Gangwon and Jeju belong to no macro region and are shown in grey.
mode province: provinces, with Seoul + Incheon + Gyeonggi merged into the Capital Area (additional results).
Boundaries: Statistics Korea (KOSTAT) 2018 province boundaries, via github.com/southkorea/southkorea-maps.
Usage: python3 korea_map.py <macro|province> <provinces_geojson> <figure_data.xlsx> <out.png>
"""
import sys, json, numpy as np, pandas as pd, matplotlib
matplotlib.use('Agg'); import matplotlib.pyplot as plt
from matplotlib.patches import PathPatch, Patch
from matplotlib.path import Path
from shapely.geometry import shape
from shapely.ops import unary_union

mode, geo_path, data_xlsx, out_png = sys.argv[1:5]
assert mode in ('macro', 'province'), mode
CODE2PROV = {'11': 'Seoul', '21': 'Busan', '22': 'Daegu', '23': 'Incheon', '24': 'Gwangju', '25': 'Daejeon', '26': 'Ulsan',
             '29': 'Sejong', '31': 'Gyeonggi', '32': 'Gangwon', '33': 'Chungbuk', '34': 'Chungnam', '35': 'Jeonbuk',
             '36': 'Jeonnam', '37': 'Gyeongbuk', '38': 'Gyeongnam', '39': 'Jeju'}
MACRO = {'SMA': ['Seoul', 'Incheon', 'Gyeonggi'], 'Chungcheong': ['Chungbuk', 'Chungnam', 'Daejeon', 'Sejong'],
         'Jeolla': ['Jeonbuk', 'Jeonnam', 'Gwangju'], 'Gyeongsang': ['Gyeongbuk', 'Gyeongnam', 'Busan', 'Ulsan', 'Daegu']}
CAP = {'Seoul', 'Incheon', 'Gyeonggi'}

geo = json.load(open(geo_path, encoding='utf-8'))
prov = {CODE2PROV[f['properties']['code']]: shape(f['geometry']).buffer(0) for f in geo['features']}
# drop Ulleungdo / Dokdo (east of 130.5E) so the mainland fills the frame
prov['Gyeongbuk'] = unary_union([g for g in getattr(prov['Gyeongbuk'], 'geoms', [prov['Gyeongbuk']]) if g.bounds[0] < 130.5])

val = pd.read_excel(data_xlsx, 'regional_indicators', index_col=0)['work_usage_per_worker']
macro_val = prov_val = val

merge = lambda gs: unary_union([g.buffer(0.002) for g in gs]).buffer(-0.002)  # closes slivers between neighbours
macro_units = {m: merge([prov[p] for p in ps]) for m, ps in MACRO.items()}
macro_units.update({'Gangwon': prov['Gangwon'], 'Jeju': prov['Jeju']})
prov_units = {'Capital Area': merge([prov[p] for p in CAP])}
prov_units.update({p: g for p, g in prov.items() if p not in CAP})

# sequential blue ramp, binned; 1 = national rate
BINS = [0, 0.25, 0.5, 0.75, 1.0, 1.5, np.inf]
RAMP = ['#cde2fb', '#86b6ef', '#5598e7', '#2a78d6', '#1c5cab', '#0d366b']
BIN_LAB = ['< 0.25', '0.25–0.5', '0.5–0.75', '0.75–1', '1–1.5', '≥ 1.5']
INK, INK2, MUTED, BG, NA = '#0b0b0b', '#52514e', '#898781', '#fcfcfb', '#e6e5e0'
color = lambda v: RAMP[np.searchsorted(BINS, v, side='right') - 1]
text_on = lambda c: '#ffffff' if RAMP.index(c) >= 3 else INK

LAT0 = np.cos(np.deg2rad(36.0))  # equirectangular, true scale at 36N


def draw(ax, geom, fc, ec=BG, lw=0.6, z=1):
    for poly in getattr(geom, 'geoms', [geom]):
        rings = [poly.exterior] + list(poly.interiors)
        verts, codes = [], []
        for r in rings:
            xy = np.asarray(r.coords)
            verts += xy.tolist(); codes += [Path.MOVETO] + [Path.LINETO] * (len(xy) - 2) + [Path.CLOSEPOLY]
        ax.add_patch(PathPatch(Path(verts, codes), fc=fc, ec=ec, lw=lw, zorder=z, joinstyle='round'))


def label_pt(geom):
    big = max(getattr(geom, 'geoms', [geom]), key=lambda g: g.area)
    p = big.representative_point() if not big.contains(big.centroid) else big.centroid
    return p.x, p.y


plt.rcParams.update({'font.size': 8, 'figure.facecolor': BG, 'axes.facecolor': BG, 'font.family': 'DejaVu Sans'})
fig, ax = plt.subplots(figsize=(5.6, 6.2))
XL, YL = (125.0, 130.2), (33.05, 38.65)


def macro_panel(ax):
    for m, g in macro_units.items():
        shown = m in MACRO
        draw(ax, g, color(macro_val[m]) if shown else NA, ec=BG, lw=1.4)
    for p, g in prov.items():  # thin province lines inside macro regions
        draw(ax, g, 'none', ec=BG, lw=0.35, z=2)
    for m, g in macro_units.items():
        shown = m in MACRO
        x, y = label_pt(g)
        off = {'SMA': (0.22, -0.25), 'Chungcheong': (0.05, -0.05), 'Jeolla': (-0.1, 0.05), 'Gyeongsang': (0.15, -0.1),
               'Gangwon': (0.1, 0.05), 'Jeju': (0, 0)}[m]
        x, y = x + off[0], y + off[1]
        if shown:
            c = color(macro_val[m])
            ax.text(x, y + 0.11, m, ha='center', va='bottom', fontsize=8, color=text_on(c))
            ax.text(x, y + 0.09, f'{macro_val[m]:.2f}', ha='center', va='top', fontsize=10.5, fontweight='bold', color=text_on(c))
        elif m == 'Gangwon':
            ax.text(x, y, 'Gangwon\nnot assigned', ha='center', va='center', fontsize=7, color=MUTED)
    ax.text(127.05, 33.38, 'Jeju\nnot assigned', ha='left', va='center', fontsize=7, color=MUTED)


def province_panel(ax):
    for u, g in prov_units.items():
        draw(ax, g, color(prov_val[u]), ec=BG, lw=0.8)
    # small metropolitan cities get an outside label with a leader line
    OUT = {'Sejong': (125.6, 37.0), 'Daejeon': (125.6, 35.95), 'Gwangju': (125.4, 35.15), 'Daegu': (129.85, 36.05),
           'Ulsan': (129.95, 35.55), 'Busan': (129.75, 34.85), 'Capital Area': None}
    for u, g in prov_units.items():
        v = prov_val[u]; c = color(v)
        x, y = label_pt(g)
        name = {'Capital Area': 'Capital\nArea'}.get(u, u)
        if OUT.get(u):
            tx, ty = OUT[u]
            ax.plot([x, tx + (0.08 if tx < x else -0.08)], [y, ty], color=INK2, lw=0.5, zorder=4)
            ax.plot(x, y, 'o', ms=2.2, color=INK, zorder=5)
            ha = 'right' if tx < x else 'left'
            ax.text(tx, ty, f'{u}  ', ha=ha, va='bottom', fontsize=7, color=INK2) if ha == 'right' else \
                ax.text(tx, ty, f'  {u}', ha=ha, va='bottom', fontsize=7, color=INK2)
            ax.text(tx, ty, f'{v:.2f}  ' if ha == 'right' else f'  {v:.2f}', ha=ha, va='top', fontsize=8.5, fontweight='bold', color=INK)
        else:
            dx, dy = {'Gyeongbuk': (0.1, 0.1), 'Chungnam': (-0.3, -0.12), 'Gyeongnam': (-0.1, 0.05), 'Jeonnam': (0.15, -0.2),
                      'Jeonbuk': (0.0, 0.0), 'Chungbuk': (0.1, 0.15), 'Gangwon': (0.1, 0.0), 'Capital Area': (0.3, -0.12)}.get(u, (0, 0))
            x, y = x + dx, y + dy
            if u == 'Jeju':
                ax.text(127.05, 33.4, u, ha='left', va='bottom', fontsize=7, color=INK2)
                ax.text(127.05, 33.38, f'{v:.2f}', ha='left', va='top', fontsize=8.5, fontweight='bold', color=INK)
                continue
            fs = 7.5 if u != 'Capital Area' else 8
            ax.text(x, y + 0.04, name, ha='center', va='bottom', fontsize=fs, color=text_on(c), linespacing=1.0)
            ax.text(x, y + 0.02, f'{v:.2f}', ha='center', va='top', fontsize=9 if u == 'Capital Area' else 8.5,
                    fontweight='bold', color=text_on(c))


(macro_panel if mode == 'macro' else province_panel)(ax)
ax.set_xlim(*XL); ax.set_ylim(*YL); ax.set_aspect(1 / LAT0); ax.axis('off')

handles = [Patch(fc=c, ec='none', label=l) for c, l in zip(RAMP, BIN_LAB)]
leg = ax.legend(handles=handles[::-1], loc='lower right', ncol=1, frameon=False, fontsize=7.5, handlelength=1.6,
                handleheight=1.0, labelspacing=0.35, bbox_to_anchor=(1.0, 0.02), alignment='left',
                title='Work use per worker\n(1 = national rate)', title_fontsize=7.5)
leg.get_title().set_color(INK2)
fig.text(0.02, 0.015, 'Sources: Anthropic Economic Index (Claude.ai), release 2026-06-26; Regional Employment Survey H2 2025;\n'
         'boundaries: Statistics Korea (2018). Ulleungdo not shown.', fontsize=6.3, color=MUTED, va='bottom')
fig.subplots_adjust(left=0.01, right=0.99, top=0.99, bottom=0.07)
fig.savefig(out_png, dpi=220, facecolor=BG)
print('saved', out_png)
