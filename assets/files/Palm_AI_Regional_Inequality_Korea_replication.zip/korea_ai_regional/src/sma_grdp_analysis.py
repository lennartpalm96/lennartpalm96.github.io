"""Seoul Capital Area (Seoul + Incheon + Gyeonggi) in Korea's GRDP, 2000-2024.
Source: KOSIS DT_1C91 (Statistics Korea, Regional Income), nominal and chained real (2020 reference), million KRW; 2024 preliminary.
- Shares: nominal (additive). Real share shown for comparison.
- Growth: real. Sejong was carved out of Chungnam (and a small part of Chungbuk) in 2013, so growth is
  reported for Chungnam+Sejong; the Chungbuk carve-out is ignored (tiny).
- Rest of Korea = sum of non-SMA provinces (approximate for chained real values).
Population: resident registration (MOIS, KOSIS DT_1B040A3), year-end, 2000-2025.
Usage: python3 sma_grdp_analysis.py <grdp_xlsx> <outdir> <population_xlsx>
"""
import sys, numpy as np, pandas as pd, matplotlib
matplotlib.use('Agg'); import matplotlib.pyplot as plt
src, outdir, pop_src = sys.argv[1:4]
EN = {'전국':'Korea','서울특별시':'Seoul','부산광역시':'Busan','대구광역시':'Daegu','인천광역시':'Incheon','광주광역시':'Gwangju',
      '대전광역시':'Daejeon','울산광역시':'Ulsan','세종특별자치시':'Sejong','경기도':'Gyeonggi','강원특별자치도':'Gangwon',
      '충청북도':'Chungbuk','충청남도':'Chungnam','전북특별자치도':'Jeonbuk','전라남도':'Jeonnam','경상북도':'Gyeongbuk',
      '경상남도':'Gyeongnam','제주특별자치도':'Jeju'}
SMA = ['Seoul','Incheon','Gyeonggi']

raw = pd.read_excel(src, '데이터', header=None)
years = raw.iloc[0, 2:].astype(str).str.replace(' p)', '', regex=False).astype(int).values
kind = raw.iloc[1, 2:].values
body = raw.iloc[2:, 2:].replace('-', np.nan).astype(float)
body.index = raw.iloc[2:, 0].map(EN)
def panel(k):
    p = body.loc[:, kind == k]; p.columns = years[kind == k]; return p
nom, real = panel('명목'), panel('실질')

def add_aggregates(p):
    p = p.copy()
    p.loc['Chungnam+Sejong'] = p.loc['Chungnam'] + p.loc['Sejong'].fillna(0)
    p.loc['SMA'] = p.loc[SMA].sum()
    provs = [r for r in EN.values() if r != 'Korea']
    p.loc['Rest'] = p.loc[[r for r in provs if r not in SMA]].sum(min_count=1)
    return p
nom, real = add_aggregates(nom), add_aggregates(real)

shares = pd.DataFrame({'SMA_share_nominal_pct': 100*nom.loc['SMA']/nom.loc['Korea'],
                       'SMA_share_real_pct': 100*real.loc['SMA']/real.loc['Korea'],
                       'SMA_real_growth_pct': 100*real.loc['SMA'].pct_change(),
                       'Rest_real_growth_pct': 100*real.loc['Rest'].pct_change(),
                       'Korea_real_growth_pct': 100*real.loc['Korea'].pct_change()})
shares['SMA_share_of_real_growth_pct'] = 100*real.loc['SMA'].diff()/(real.loc['SMA'].diff()+real.loc['Rest'].diff())
shares.index.name = 'year'

def cagr(s, a, b): return 100*((s[b]/s[a])**(1/(b-a))-1)
periods = [(2000, 2014), (2014, 2024)]
regions = ['Korea','SMA','Rest'] + SMA + ['Busan','Daegu','Gwangju','Daejeon','Ulsan','Gangwon','Chungbuk','Chungnam+Sejong',
                                         'Jeonbuk','Jeonnam','Gyeongbuk','Gyeongnam','Jeju']
g = pd.DataFrame({f'real_growth_{a}_{b}': [cagr(real.loc[r], a, b) for r in regions] for a, b in periods}, index=regions)
g['change_pp'] = g.iloc[:, 1] - g.iloc[:, 0]
g['total_real_growth_2014_24_pct'] = [100*(real.loc[r, 2024]/real.loc[r, 2014]-1) for r in regions]
g['nominal_share_2000_pct'] = [100*nom.loc[r, 2000]/nom.loc['Korea', 2000] for r in regions]
g['nominal_share_2024_pct'] = [100*nom.loc[r, 2024]/nom.loc['Korea', 2024] for r in regions]

# share of cumulative real growth and counterfactual decomposition (real)
S, R = real.loc['SMA'], real.loc['Rest']
cum = {f'{a}-{b}': 100*(S[b]-S[a])/((S[b]-S[a])+(R[b]-R[a])) for a, b in periods}
gS, gR = (S[2014]/S[2000])**(1/14), (R[2014]/R[2000])**(1/14)
cfS, cfR = S[2014]*gS**10, R[2014]*gR**10
sh = lambda a, b: 100*a/(a+b)
cf = pd.Series({'real share 2014': sh(S[2014], R[2014]), 'real share 2024 (actual)': sh(S[2024], R[2024]),
                'both keep 2000-14 growth': sh(cfS, cfR), 'SMA actual, Rest keeps 2000-14 growth': sh(S[2024], cfR),
                'SMA keeps 2000-14 growth, Rest actual': sh(cfS, R[2024])})

with pd.ExcelWriter(f'{outdir}/sma_grdp_2000_2024.xlsx') as xl:
    pd.DataFrame({'note': [__doc__]}).to_excel(xl, 'README', index=False)
    shares.round(3).to_excel(xl, 'SMA_share_by_year')
    g.round(2).to_excel(xl, 'growth_by_region')
    pd.Series(cum, name='SMA share of cumulative real growth (%)').round(1).to_frame().to_excel(xl, 'growth_contribution')
    cf.round(2).to_frame('SMA share (%)').to_excel(xl, 'counterfactual')
    nom.round(0).to_excel(xl, 'nominal_levels'); real.round(0).to_excel(xl, 'real_levels')

# ---------- population (resident registration, year-end; MOIS via KOSIS DT_1B040A3) ----------
popraw = pd.read_excel(pop_src, '데이터', header=None)
pyears = popraw.iloc[0, 1:].astype(str).values
pbody = popraw.iloc[2:, 1:].replace('-', np.nan).astype(float)
pbody.index = popraw.iloc[2:, 0]; pbody.columns = pyears
pbody = pbody[[c for c in pyears if c.isdigit()]]; pbody.columns = pbody.columns.astype(int)
pop_share = 100 * pbody.loc[['서울특별시', '인천광역시', '경기도']].sum() / pbody.loc['전국']
shares = shares.join(pop_share.rename('SMA_share_population_pct'), how='outer')
gdp_pc_ratio = (nom.loc['SMA'] / pbody.loc[['서울특별시','인천광역시','경기도']].sum().reindex(nom.columns)) / \
               (nom.loc['Rest'] / (pbody.loc['전국'] - pbody.loc[['서울특별시','인천광역시','경기도']].sum()).reindex(nom.columns))
shares['SMA_vs_rest_nominal_GRDP_per_capita'] = gdp_pc_ratio
with pd.ExcelWriter(f'{outdir}/sma_grdp_2000_2024.xlsx', engine='openpyxl', mode='a', if_sheet_exists='replace') as xl:
    shares.round(3).to_excel(xl, 'SMA_share_by_year')

# ---------- chart ----------
y = shares.SMA_share_nominal_pct.dropna(); yr = shares.SMA_share_real_pct.dropna(); yp = shares.SMA_share_population_pct.dropna()
BLUE, ORANGE, GRAY, INK, INK2, bg = '#2a78d6', '#eb6834', '#8f8e88', '#0b0b0b', '#52514e', '#fcfcfb'
fig, ax = plt.subplots(figsize=(7.5, 4.4), dpi=200)
fig.patch.set_facecolor(bg); ax.set_facecolor(bg)
ax.axhline(50, color=GRAY, lw=1, ls=(0, (4, 3)), zorder=1)
ax.text(2000.1, 50.08, '50%', color=INK2, fontsize=8, va='bottom')
ax.plot(yr.index, yr.values, color=GRAY, lw=1.5, zorder=2)
ax.plot(y.index, y.values, color=BLUE, lw=2, zorder=3)
ax.plot(yp.index, yp.values, color=ORANGE, lw=2, zorder=3)
fg = int(y[y > 50].index.min()); fp = int(yp[yp > 50].index.min())
ax.scatter([fg], [y.loc[fg]], s=36, color=BLUE, edgecolor=bg, linewidth=2, zorder=4)
ax.scatter([fp], [yp.loc[fp]], s=36, color=ORANGE, edgecolor=bg, linewidth=2, zorder=4)
ax.annotate(f'GRDP above half: {fg}', (fg, y.loc[fg]), xytext=(-8, 12), textcoords='offset points', ha='right', fontsize=8.5, color=INK)
ax.annotate(f'Population above half: {fp}', (fp, yp.loc[fp]), xytext=(8, -16), textcoords='offset points', ha='left', fontsize=8.5, color=INK)
ly = {'GRDP, nominal': (y, BLUE), 'GRDP, real': (yr, GRAY), 'Population': (yp, ORANGE)}
end_lab = {'GRDP, real': yr.iloc[-1] + 0.12, 'GRDP, nominal': y.iloc[-1] - 0.22, 'Population': yp.iloc[-1]}
for k, (ser, col) in ly.items():
    ax.scatter([ser.index[-1]], [ser.iloc[-1]], s=16, color=col, zorder=4)
    ax.text(2025.6, end_lab[k], f'{k} {ser.iloc[-1]:.1f}%', color=col if col != GRAY else INK2, fontsize=8, va='center')
ax.annotate(f'{y.iloc[0]:.1f}%', (2000, y.iloc[0]), xytext=(2, -16), textcoords='offset points', ha='left', fontsize=8, color=INK2)
ax.annotate(f'{yp.iloc[0]:.1f}%', (2000, yp.iloc[0]), xytext=(4, -14), textcoords='offset points', ha='left', fontsize=8, color=INK2)
lo = min(y.min(), yr.min(), yp.min()); hi = max(y.max(), yr.max(), yp.max())
ax.set_ylim(np.floor(lo) - 0.5, np.ceil(hi) + 0.5); ax.set_xlim(1999.5, 2031)
ax.set_xticks(range(2000, 2025, 4)); ax.tick_params(colors=INK2, labelsize=8, length=0)
ax.yaxis.set_major_formatter(matplotlib.ticker.FuncFormatter(lambda v, _: f'{v:.0f}%'))
ax.grid(axis='y', color='#e6e5e0', lw=0.8); [sp.set_visible(False) for sp in ax.spines.values()]
ax.set_title("Seoul Capital Area share of Korea's GRDP and population, 2000–2025", loc='left', fontsize=11, color=INK, pad=14)
fig.text(0.08, 0.012, 'Seoul + Incheon + Gyeonggi. GRDP: KOSIS DT_1C91 (Statistics Korea), real = chained 2020 prices, 2024 preliminary.\n'
         'Population: resident registration, year-end (Ministry of the Interior and Safety, KOSIS DT_1B040A3).', fontsize=6.5, color=INK2)
plt.tight_layout(rect=(0, 0.05, 1, 1)); plt.savefig(f'{outdir}/sma_grdp_share_2000_2024.png', facecolor=bg)

pd.set_option('display.width', 220)
print(shares.round(2).to_string())
