"""Regional hourly-wage differentials within occupation, Regional Employment Survey H2 2025 (Oct 2025).

Sample: wage earners (상용 + 임시/일용) with positive hours in the survey week; hourly wage =
  avg monthly wage over last 3 months (10k KRW) / (main-job weekly hours x 4.345); bottom/top 0.5% trimmed.
Region = workplace province, Seoul/Incheon/Gyeonggi merged into Capital Area (reference category).
WLS with 시도가중값, SEs clustered by household.

Specs (dependent variable: log hourly wage):
  (1) region FE only
  (2) + occupation FE (KSCO-8 2-digit)
  (3) + sex, age, age^2, education, marital status, tenure, tenure^2, firm size, temporary/daily status,
        fixed-term contract, industry FE (KSIC-11 2-digit)
  (4) spec (3) with Capital Area x SOC major group interactions: Capital Area premium within each SOC group
      (KSCO codes split across SOC groups enter fractionally via the crosswalk weights).
Usage: python3 regional_wage_premia.py <wage_dir> <crosswalk_csv> <capital_area_xlsx> <out_xlsx>
"""
import sys, numpy as np, pandas as pd, statsmodels.formula.api as smf
wage_dir, xw_path, cap_xlsx, out = sys.argv[1:5]
NAME = {'11':'Seoul','21':'Busan','22':'Daegu','23':'Incheon','24':'Gwangju','25':'Daejeon','26':'Ulsan','29':'Sejong',
        '31':'Gyeonggi','32':'Gangwon','33':'Chungbuk','34':'Chungnam','35':'Jeonbuk','36':'Jeonnam','37':'Gyeongbuk',
        '38':'Gyeongnam','39':'Jeju'}
UNIT = {k: ('Capital Area' if k in {'11','23','31'} else v) for k, v in NAME.items()}
UNITS = ['Capital Area'] + [v for k, v in NAME.items() if k not in {'11','23','31'}]

m = pd.read_pickle(f'{wage_dir}/micro.pkl')
e = m[(m['경제활동구분코드']=='1') & m['현직장종사상지위코드'].isin(['1','2'])].copy()
e['w'] = e['시도가중값'].astype(float)
e['wage'] = pd.to_numeric(e['최근3개월_월평균급여'], errors='coerce')
e['hours'] = pd.to_numeric(e['조사대상주간_주업근무시간수'], errors='coerce')
e = e[(e.wage > 0) & (e.hours > 0)]
e['hw'] = e.wage / (e.hours * 4.345)
lo, hi = e.hw.quantile([0.005, 0.995]); e = e[e.hw.between(lo, hi)]
e['lhw'] = np.log(e.hw)
e['region'] = pd.Categorical(e['사업체직장소재지_행정구역코드'].map(UNIT), categories=UNITS)
e = e[e.region.notna()]
e['female'] = (e['성별코드']=='2').astype(int)
e['age'] = pd.to_numeric(e['만연령']); e['age2'] = e.age**2/100
st = pd.to_datetime(e['조사대상주간_직장시작연월'], format='%Y%m', errors='coerce')
e['tenure'] = ((pd.Timestamp('2025-10-01') - st).dt.days / 365.25).clip(lower=0).fillna(0); e['tenure2'] = e.tenure**2/10
e['temp'] = (e['현직장종사상지위코드']=='2').astype(int)
e['fixedterm'] = (e['고용계약기간정함여부']=='1').astype(int)
for v, c in [('edu','학력코드'),('marital','혼인상태코드'),('size','직장종사자규모코드'),('ind','2자리_11차산업중분류코드'),('occ','2자리_8차직업중분류코드')]:
    e[v] = e[c].fillna('NA')
e['hh'] = e['가구단위일련번호']
print('N =', len(e), ' hourly wage p0.5/p99.5 =', round(lo,2), round(hi,2))

RC = 'C(region, Treatment("Capital Area"))'
X = 'female + age + age2 + C(edu) + C(marital) + tenure + tenure2 + C(size) + temp + fixedterm + C(ind)'
specs = {'(1) raw': f'lhw ~ {RC}', '(2) + occupation FE': f'lhw ~ {RC} + C(occ)', '(3) + all controls': f'lhw ~ {RC} + C(occ) + {X}'}
rows = []
for name, f in specs.items():
    r = smf.wls(f, data=e, weights=e.w).fit(cov_type='cluster', cov_kwds={'groups': pd.factorize(e.hh)[0]})
    for u in UNITS[1:]:
        k = f'{RC}[T.{u}]'
        rows.append(dict(spec=name, region=u, coef=r.params[k], se=r.bse[k]))
    print(name, 'R2 =', round(r.rsquared, 3))
res = pd.DataFrame(rows)
res['premium_pct'] = 100*(np.exp(res.coef)-1)
res['ci_low_pct'] = 100*(np.exp(res.coef-1.96*res.se)-1); res['ci_high_pct'] = 100*(np.exp(res.coef+1.96*res.se)-1)
wide = res.pivot(index='region', columns='spec', values='premium_pct').reindex(UNITS[1:])

# (4) Capital Area premium within SOC major groups (fractional SOC assignment)
xw = pd.read_csv(xw_path, dtype={'ksco8_2d':str,'soc_major_1':str,'soc_major_2':str})
alloc = pd.concat([xw[['ksco8_2d','soc_major_1','weight_1','soc_label_1']].set_axis(['occ','soc','a','soc_label'],axis=1),
                   xw[['ksco8_2d','soc_major_2','weight_2','soc_label_2']].set_axis(['occ','soc','a','soc_label'],axis=1)]).dropna()
f = e.merge(alloc, on='occ'); f['w2'] = f.w * f.a
f['cap'] = (f.region=='Capital Area').astype(int)
# identification: KSCO occupation FE + SOC-specific capital premium (rest of Korea pooled as reference).
# No separate C(soc) main effects: they are collinear with the occupation FE except through the duplicated rows of
# KSCO codes split across SOC groups, where they would be identified only from that artificial duplication.
f4 = f'lhw ~ C(soc):cap + C(occ) + {X}'
r4 = smf.wls(f4, data=f, weights=f.w2).fit(cov_type='cluster', cov_kwds={'groups': pd.factorize(f.hh)[0]})
soc_rows = []
labels = alloc.drop_duplicates('soc').set_index('soc').soc_label
for s in sorted(f.soc.unique()):
    k = f'C(soc)[{s}]:cap'
    if k in r4.params:
        sub = f[f.soc==s]
        soc_rows.append(dict(soc=s, soc_label=labels[s], coef=r4.params[k], se=r4.bse[k],
                             n_capital=int((sub.cap==1).sum()), n_rest=int((sub.cap==0).sum())))
soc = pd.DataFrame(soc_rows)
soc['capital_premium_pct'] = 100*(np.exp(soc.coef)-1)
soc['ci_low_pct'] = 100*(np.exp(soc.coef-1.96*soc.se)-1); soc['ci_high_pct'] = 100*(np.exp(soc.coef+1.96*soc.se)-1)

# link to AI usage intensity (Capital Area intensity from capital_area_analysis)
try:
    I = pd.read_excel(cap_xlsx, 'intensity_workplace', index_col=0)
    I.columns = [c.split(' ')[0] for c in I.columns]
    soc['capital_ai_intensity'] = soc.soc.map(I.loc['Capital Area'])
    rest = pd.read_excel(cap_xlsx, 'long'); rest = rest[(rest.region_def=='workplace')]
    rest['soc'] = rest.soc.astype(str).str.zfill(2)
    agg = rest.assign(cap=rest.unit=='Capital Area').groupby(['soc','cap'])[['U','P']].sum().unstack()
    soc['capital_vs_rest_ai_ratio'] = soc.soc.map((agg[('U',True)]/agg[('P',True)])/(agg[('U',False)]/agg[('P',False)]))
except Exception as ex:
    print('AI link skipped:', ex)

with pd.ExcelWriter(out) as xl:
    pd.DataFrame({'note':[__doc__]}).to_excel(xl, 'README', index=False)
    wide.round(1).to_excel(xl, 'premia_vs_capital_pct')
    res.round(4).to_excel(xl, 'premia_long', index=False)
    soc.sort_values('capital_premium_pct', ascending=False).round(3).to_excel(xl, 'capital_premium_by_SOC', index=False)

pd.set_option('display.width', 250)
print(wide.round(1).to_string())
print(soc.sort_values('capital_premium_pct', ascending=False)[['soc_label','capital_premium_pct','ci_low_pct','ci_high_pct','n_capital','n_rest'] + [c for c in ['capital_ai_intensity','capital_vs_rest_ai_ratio'] if c in soc]].round(2).to_string(index=False))
if 'capital_vs_rest_ai_ratio' in soc:
    ok = soc[np.isfinite(soc.capital_vs_rest_ai_ratio)]
    print('corr(capital wage premium, log capital-vs-rest AI ratio) =', round(np.corrcoef(ok.coef, np.log(ok.capital_vs_rest_ai_ratio))[0,1], 2), 'n =', len(ok))
