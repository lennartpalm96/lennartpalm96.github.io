"""Composition of 'Computer and Mathematical' (SOC 15) usage: detailed occupations for Korea and global,
and sub-group shares by region (published cells only; small cells are suppressed outside large provinces).
Usage: python3 cm_breakdown.py <aei_csv> <outdir>
"""
import sys, pandas as pd
aei_csv, outdir = sys.argv[1:3]
MAC = {'SMA':['KR-11','KR-28','KR-41'],'Chungcheong':['KR-43','KR-44','KR-30','KR-50'],'Jeolla':['KR-45','KR-46','KR-29'],
       'Gyeongsang':['KR-47','KR-48','KR-26','KR-31','KR-27'],'Gangwon':['KR-42'],'Jeju':['KR-49']}
inv = {g: m for m, gs in MAC.items() for g in gs}
grp = lambda c: ('Document management' if c=='15-1299.03' else 'User support' if c=='15-1232.00' else
                 'Math/stats/data' if c.startswith('15-2') else 'GIS' if c=='15-1299.02' else 'Software/IT')
d = pd.read_csv(aei_csv)
s = d[(d.category_name=='soc_occupation') & (d.hierarchy_level==0) & (d.metric_id=='pct') & d.node_external_id.astype(str).str.startswith('15-')]
nat = s[s.geo_id.isin(['KOR','GLOBAL'])].groupby(['node_external_id','node_name','geo_id']).value.mean().unstack().sort_values('KOR', ascending=False)
nat['subgroup'] = [grp(c) for c in nat.index.get_level_values(0)]
u = d[(d.category_name=='overall') & (d.metric_id=='usage_pct') & d.geo_id.str.startswith('KR-')].groupby('geo_id').value.mean()
p = s[s.geo_id.str.startswith('KR-')].groupby(['geo_id','node_external_id']).value.mean().reset_index()
p['U'] = p.geo_id.map(u)*p.value/100; p['subgroup'] = p.node_external_id.map(grp); p['macro'] = p.geo_id.map(inv)
mac = p.groupby(['macro','subgroup']).U.sum().unstack(); mac = 100*mac.div(mac.sum(1), axis=0)
prov = p.groupby(['geo_id','subgroup']).U.sum().unstack(); prov = 100*prov.div(prov.sum(1), axis=0)
with pd.ExcelWriter(f'{outdir}/computer_math_breakdown.xlsx') as xl:
    pd.DataFrame({'note': [__doc__]}).to_excel(xl, 'README', index=False)
    nat.round(3).to_excel(xl, 'detailed_KOR_vs_GLOBAL')
    mac.round(1).to_excel(xl, 'subgroup_share_macro')
    prov.round(1).to_excel(xl, 'subgroup_share_province')
    p.groupby('geo_id').size().rename('published_detailed_cells').to_frame().to_excel(xl, 'published_cells')
print(mac.round(1).to_string())
