"""Read the Regional Employment Survey microdata (CP949-encoded CSV) once and cache it as a pickle.
Usage: python3 00_prepare.py <res_csv> <interim_dir>
"""
import sys, os, pandas as pd
src, interim = sys.argv[1:3]
os.makedirs(interim, exist_ok=True)
m = pd.read_csv(src, encoding='cp949', dtype=str)
m.to_pickle(f'{interim}/micro.pkl')
print(f'{len(m):,} rows, {m.shape[1]} columns -> {interim}/micro.pkl')
