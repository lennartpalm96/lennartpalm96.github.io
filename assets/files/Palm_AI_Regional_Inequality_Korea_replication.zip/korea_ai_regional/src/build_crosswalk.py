"""First-guess crosswalk: KSCO 8th revision 2-digit (중분류) -> SOC 2018 major groups.
Each KSCO code gets up to two SOC major groups with allocation weights summing to 1.
Employment counts: Regional Employment Survey (지역별고용조사), H2 2025, employed persons, weighted by 시도가중값."""
import sys, pandas as pd
W, CODEBOOK, OUTDIR = sys.argv[1:4]  # interim dir with micro.pkl, RES codebook xlsx, output dir

SOC = {'11':'Management','13':'Business and Financial Operations','15':'Computer and Mathematical',
'17':'Architecture and Engineering','19':'Life, Physical, and Social Science','21':'Community and Social Service',
'23':'Legal','25':'Educational Instruction and Library','27':'Arts, Design, Entertainment, Sports, and Media',
'29':'Healthcare Practitioners and Technical','31':'Healthcare Support','33':'Protective Service',
'35':'Food Preparation and Serving Related','37':'Building and Grounds Cleaning and Maintenance',
'39':'Personal Care and Service','41':'Sales and Related','43':'Office and Administrative Support',
'45':'Farming, Fishing, and Forestry','47':'Construction and Extraction','49':'Installation, Maintenance, and Repair',
'51':'Production','53':'Transportation and Material Moving'}

# ksco: (english label, soc1, w1, soc2, w2, confidence, note)
X = {
'11':('Legislators, senior government officials and corporate executives','11',1,None,0,'high',''),
'12':('Administrative, business support and marketing managers','11',1,None,0,'high',''),
'13':('Professional services managers','11',1,None,0,'high',''),
'14':('Construction, electricity and production managers','11',1,None,0,'high',''),
'15':('Sales and customer service managers','11',1,None,0,'high','Includes hotel/restaurant managers (SOC 11-9051, 11-9081)'),
'21':('Science professionals and related','19',1,None,0,'high',''),
'22':('ICT professionals and technicians','15',0.85,'17',0.15,'high','Telecom/broadcast engineers fall under SOC 17'),
'23':('Engineering professionals and technicians','17',1,None,0,'high','Some environmental/safety specialists are SOC 19'),
'24':('Health professionals and related','29',1,None,0,'high',''),
'25':('Social welfare and religious professionals','21',1,None,0,'high',''),
'26':('Education professionals and related','25',1,None,0,'high','Childcare teachers (보육교사) included; SOC puts childcare workers in 39'),
'27':('Legal and administrative professionals','23',0.7,'13',0.3,'medium','272 administrative professionals have no clean SOC counterpart'),
'28':('Business and finance professionals','13',1,None,0,'high',''),
'29':('Culture, arts, sports and other professionals','27',1,None,0,'high',''),
'31':('Planning, sales-admin and HR clerks','13',0.6,'43',0.4,'low','Large generic Korean office category; split between analysts/HR specialists (13) and clerks (43) is a guess'),
'32':('Materials, production and transport clerks','43',1,None,0,'high','SOC 43-5xxx'),
'33':('Accounting, bookkeeping and statistical clerks','43',1,None,0,'high','SOC 43-3031, 43-9111'),
'34':('Financial clerks','43',0.8,'13',0.2,'medium','Loan officers/underwriters are SOC 13'),
'35':('Legal, audit and government administration clerks','43',0.7,'13',0.3,'low','Mostly civil-service administration; paralegals (SOC 23) not split out'),
'36':('Counseling, information and reception clerks','43',1,None,0,'high','Customer service reps, receptionists'),
'37':('General support clerks','43',1,None,0,'high',''),
'41':('Police, fire and security services','33',1,None,0,'high',''),
'42':('Care and health services workers','31',0.7,'39',0.3,'medium','Care aides (31) vs childcare/personal care aides (39)'),
'43':('Personal services workers','39',1,None,0,'high','Hairdressers, wedding/funeral, pet care'),
'44':('Transport and leisure services workers','39',0.6,'53',0.4,'medium','Tour/recreation workers (39) vs flight attendants (53)'),
'45':('Cooking and food services workers','35',1,None,0,'high',''),
'51':('Sales workers','41',1,None,0,'high','Sales reps, insurance and real estate agents'),
'52':('Store sales and rental workers','41',1,None,0,'high','Cashiers are SOC 41-2011'),
'53':('Telemarketing, door-to-door and street sales','41',1,None,0,'high',''),
'61':('Skilled agricultural and livestock workers','45',1,None,0,'medium','Mostly self-employed farmers; SOC codes farm operators as 11-9013 (Management)'),
'62':('Skilled forestry workers','45',1,None,0,'high',''),
'63':('Skilled fishery workers','45',1,None,0,'high',''),
'71':('Food processing craft workers','51',1,None,0,'high','Bakers, butchers'),
'72':('Textile, clothing and leather craft workers','51',1,None,0,'high',''),
'73':('Wood, furniture, instrument and sign craft workers','51',1,None,0,'high',''),
'74':('Metal forming craft workers','51',1,None,0,'high','Welders'),
'75':('Transport and machinery craft workers','49',1,None,0,'high','Vehicle/machinery mechanics'),
'76':('Electrical and electronics craft workers','47',0.5,'49',0.5,'medium','Electricians (47) vs electronics repairers (49)'),
'77':('ICT and broadcast equipment craft workers','49',1,None,0,'high','Telecom installers/repairers'),
'78':('Construction and mining craft workers','47',1,None,0,'high',''),
'79':('Other craft and related workers','51',1,None,0,'low','Residual category, content unclear'),
'81':('Food processing machine operators','51',1,None,0,'high',''),
'82':('Textile and footwear machine operators','51',1,None,0,'high',''),
'83':('Chemical machine operators','51',1,None,0,'high',''),
'84':('Metal and non-metal machine operators','51',1,None,0,'high',''),
'85':('Machinery manufacturing operators and assemblers','51',1,None,0,'high',''),
'86':('Electrical/electronic machine operators and assemblers','51',1,None,0,'high',''),
'87':('Drivers and transport machine operators','53',1,None,0,'high',''),
'88':('Water, sewage and recycling plant operators','51',1,None,0,'medium','Refuse collectors would be SOC 53'),
'89':('Wood, printing and other machine operators','51',1,None,0,'high',''),
'91':('Construction and mining laborers','47',1,None,0,'high',''),
'92':('Transport laborers','53',1,None,0,'high','Movers, parcel delivery'),
'93':('Manufacturing laborers','51',0.7,'53',0.3,'medium','Production helpers (51) vs packers/hand laborers (53)'),
'94':('Cleaning and building management laborers','37',0.75,'33',0.25,'medium','Apartment security guards (경비원) are SOC 33-9032'),
'95':('Domestic, food and sales elementary workers','35',0.5,'37',0.5,'low','Kitchen helpers (35) vs housekeepers (37); sales-related helpers not split out'),
'99':('Agricultural, fishery and other service laborers','45',0.5,'53',0.5,'low','Farm laborers (45) vs parking/meter/other service laborers (53/39)'),
'A0':('Armed forces',None,0,None,0,'n/a','No SOC civilian major group; not in AEI'),
}

codes = pd.read_excel(CODEBOOK,'코드정보',header=1)
codes.columns=['no','item','code','label','note']
codes = codes[codes.item=='2자리_8차직업중분류코드'].set_index('code').label

m = pd.read_pickle(f'{W}/micro.pkl')
e = m[m['경제활동구분코드']=='1'].copy()
e['w'] = e['시도가중값'].astype(float)
e['wage'] = pd.to_numeric(e['최근3개월_월평균급여'], errors='coerce')
g = e.groupby('2자리_8차직업중분류코드').agg(n_obs=('w','size'), employment=('w','sum'))
ww = e[e.wage.notna()]
g['mean_wage_10k_krw'] = ww.groupby('2자리_8차직업중분류코드').apply(lambda x:(x.wage*x.w).sum()/x.w.sum(), include_groups=False)

rows=[]
for k,(en,s1,w1,s2,w2,conf,note) in X.items():
    rows.append(dict(ksco8_2d=k, ksco_label_ko=codes.get(k), ksco_label_en=en,
        n_obs=g.n_obs.get(k,0), employment=round(g.employment.get(k,0)), emp_share_pct=round(100*g.employment.get(k,0)/g.employment.sum(),2),
        mean_wage_10k_krw=round(g.mean_wage_10k_krw.get(k,float('nan')),1),
        soc_major_1=s1, soc_label_1=SOC.get(s1), weight_1=w1,
        soc_major_2=s2, soc_label_2=SOC.get(s2), weight_2=w2 if s2 else None,
        confidence=conf, note=note))
xw = pd.DataFrame(rows)
xw.to_csv(f'{OUTDIR}/ksco8_2d_to_soc_major.csv', index=False, encoding='utf-8-sig')

# implied employment by SOC major group
long = pd.concat([xw[['ksco8_2d','employment','soc_major_1','weight_1']].rename(columns={'soc_major_1':'soc','weight_1':'w'}),
                  xw[['ksco8_2d','employment','soc_major_2','weight_2']].rename(columns={'soc_major_2':'soc','weight_2':'w'})]).dropna(subset=['soc'])
long['emp'] = long.employment*long.w
s = long.groupby('soc').emp.sum().to_frame()
s['soc_label'] = s.index.map(SOC)
s['emp_share_pct'] = 100*s.emp/s.emp.sum()
s.round(2).to_csv(f'{OUTDIR}/soc_major_employment_korea_2025H2.csv', encoding='utf-8-sig')
print(xw.confidence.value_counts().to_dict())
print(s.sort_values('emp_share_pct',ascending=False).round(1).to_string())
