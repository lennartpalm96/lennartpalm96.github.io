"""Regional x occupational Claude usage in Korea vs. an equal-intensity benchmark.

Observed:   U[r,s] = usage_pct[r] * pct[r,s] / 100       (share of total Korean usage, AEI Apr+May 2026 avg)
Benchmark:  P[r,s] = U_KOR[s] * E[r,s] / E[s]            (national occupation usage split by regional employment)
Intensity:  I[r,s] = U[r,s] / P[r,s]                     (1 = region uses occupation-s tasks in proportion to its s-workers)

E[r,s] from the Regional Employment Survey H2 2025 (employed, weighted), KSCO-8 2-digit mapped to SOC major
groups with the first-guess crosswalk. Computed twice: region = workplace and region = residence.
Usage: python3 usage_by_region_occupation.py <aei_dir> <wage_dir> <crosswalk_csv> <out_xlsx>
"""
import sys, pandas as pd, numpy as np
aei_dir, wage_dir, xw_path, out = sys.argv[1:5]

AEI2REG = {'KR-11':'11','KR-26':'21','KR-27':'22','KR-28':'23','KR-29':'24','KR-30':'25','KR-31':'26','KR-50':'29',
           'KR-41':'31','KR-42':'32','KR-43':'33','KR-44':'34','KR-45':'35','KR-46':'36','KR-47':'37','KR-48':'38','KR-49':'39'}
NAME = {'11':'Seoul','21':'Busan','22':'Daegu','23':'Incheon','24':'Gwangju','25':'Daejeon','26':'Ulsan','29':'Sejong',
        '31':'Gyeonggi','32':'Gangwon','33':'Chungbuk','34':'Chungnam','35':'Jeonbuk','36':'Jeonnam','37':'Gyeongbuk',
        '38':'Gyeongnam','39':'Jeju'}
REG_ORDER = list(NAME.values())

# ---------- AEI: observed usage shares ----------
d = pd.read_csv(f'{aei_dir}/aei_claude_ai_2026-06-26.csv')
d = d[d.geo_id.isin(list(AEI2REG) + ['KOR'])]
soc_lab = d[(d.category_name=='soc_occupation')&(d.hierarchy_level==1)][['node_external_id','node_name']].drop_duplicates()
soc_lab['soc'] = soc_lab.node_external_id.str[:2]
SOC = soc_lab.set_index('node_name').soc.to_dict()
SOCNAME = {v:k for k,v in SOC.items()}

usage = (d[(d.category_name=='overall')&(d.metric_id=='usage_pct')&(d.geo_id!='KOR')]
         .groupby('geo_id').value.mean())                          # avg of Apr/May, % of Korean usage
occ = d[(d.category_name=='soc_occupation')&(d.hierarchy_level==1)&(d.metric_id=='pct')].copy()
occ['soc'] = occ.node_name.map(SOC)
nmonths = occ.groupby(['geo_id','soc']).value.size()
occ = occ.groupby(['geo_id','soc']).value.mean()                    # avg over months where published

kor = occ.loc['KOR']                                               # national occupation mix, % of Korean usage
reg = occ.drop('KOR', level=0).reset_index()
reg['region'] = reg.geo_id.map(AEI2REG).map(NAME)
reg['U'] = reg.geo_id.map(usage) * reg.value / 100                 # % of total Korean usage
reg['months_published'] = [nmonths[(g,s)] for g,s in zip(reg.geo_id, reg.soc)]
U = reg.pivot(index='region', columns='soc', values='U').reindex(REG_ORDER)

# ---------- wage survey: employment by region x SOC ----------
m = pd.read_pickle(f'{wage_dir}/micro.pkl')
e = m[m['경제활동구분코드']=='1'].copy()
e['w'] = e['시도가중값'].astype(float)
xw = pd.read_csv(xw_path, dtype={'ksco8_2d':str,'soc_major_1':str,'soc_major_2':str})
alloc = pd.concat([xw[['ksco8_2d','soc_major_1','weight_1']].set_axis(['ksco','soc','a'],axis=1),
                   xw[['ksco8_2d','soc_major_2','weight_2']].set_axis(['ksco','soc','a'],axis=1)]).dropna()

def employment(regcol):
    g = e.groupby([regcol,'2자리_8차직업중분류코드']).w.sum().rename('emp').reset_index()
    g.columns = ['reg','ksco','emp']
    g = g.merge(alloc, on='ksco')
    g['emp'] *= g.a
    g = g[g.reg.isin(NAME)]
    g['region'] = g.reg.map(NAME)
    return g.pivot_table(index='region', columns='soc', values='emp', aggfunc='sum').reindex(REG_ORDER).fillna(0)

res = {}
for label, col in [('workplace','사업체직장소재지_행정구역코드'), ('residence','2자리_행정구역시도코드')]:
    E = employment(col)
    P = E.div(E.sum()) .mul(kor.reindex(E.columns))                # benchmark, % of Korean usage
    I = U.reindex(columns=P.columns) / P
    # region totals: actual vs composition-only prediction vs plain employment share
    tot = pd.DataFrame({'usage_share_actual': usage.rename(index=lambda g: NAME[AEI2REG[g]]).reindex(REG_ORDER),
                        'employment_share': 100*E.sum(1)/E.values.sum(),
                        'usage_share_if_equal_intensity': P.sum(1)})
    tot['ratio_actual_to_equal_intensity'] = tot.usage_share_actual / tot.usage_share_if_equal_intensity
    res[label] = dict(E=E, P=P, I=I, tot=tot)

# ---------- output ----------
def named(df):
    return df.rename(columns=lambda s: f'{s} {SOCNAME.get(s,"")}')
order = kor.sort_values(ascending=False).index
with pd.ExcelWriter(out) as xl:
    readme = pd.DataFrame({'note':[
        'U = observed share of total Korean Claude.ai usage (%), region x SOC major group; AEI release 2026-06-26, average of Apr & May 2026.',
        'Blank U = cell suppressed by Anthropic in both months (small usage), not zero.',
        'P = benchmark share if every region used occupation-s tasks in proportion to its share of Korean s-employment.',
        'I = U / P. 1 = proportional; >1 = more usage per worker than the national average for that occupation.',
        'Employment: Regional Employment Survey H2 2025, employed persons, weighted (시도가중값); KSCO-8 2-digit -> SOC via first-guess crosswalk.',
        'workplace = 사업체직장소재지_행정구역코드; residence = 2자리_행정구역시도코드.',
        'AEI occupations describe the task in a conversation, not the user (students, personal use included).']})
    readme.to_excel(xl, 'README', index=False)
    named(U[order]).round(3).to_excel(xl, 'U_observed')
    for label in res:
        r = res[label]
        r['tot'].round(3).to_excel(xl, f'region_totals_{label}')
        named(r['I'][order]).round(2).to_excel(xl, f'I_intensity_{label}')
        named(r['P'][order]).round(3).to_excel(xl, f'P_benchmark_{label}')
        named((100*r['E']/r['E'].values.sum())[order]).round(3).to_excel(xl, f'E_emp_share_{label}')
    # long format for R
    longs=[]
    for label in res:
        r=res[label]
        L = pd.concat({'U':U.reindex(columns=r['P'].columns).stack(future_stack=True),'P':r['P'].stack(),'E':r['E'].stack(),'I':r['I'].stack(future_stack=True)},axis=1).reset_index()
        L['region_def']=label; longs.append(L)
    long = pd.concat(longs)
    long['soc_label']=long.soc.map(SOCNAME)
    long.to_excel(xl,'long',index=False)
long.to_csv(out.replace('.xlsx','_long.csv'), index=False)

pd.set_option('display.width',250)
for label in res:
    print('\n===',label); print(res[label]['tot'].round(2).to_string())
top = [s for s in order[:8]]
print('\nIntensity (workplace), top-8 occupations:'); print(res['workplace']['I'][top].rename(columns=SOCNAME).round(2).to_string())
print('\nIntensity (residence), top-8:'); print(res['residence']['I'][top].rename(columns=SOCNAME).round(2).to_string())
# share of national usage observed in regional cells
print('\nobserved coverage of national usage by occupation:', (U.sum()/kor).round(2).to_dict())
