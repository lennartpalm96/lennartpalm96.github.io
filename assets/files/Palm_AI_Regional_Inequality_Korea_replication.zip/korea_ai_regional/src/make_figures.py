"""Figures: regional AI (Claude) usage in Korea vs. occupations, wages, education and students.

Modes: 'province17' = all 17 provinces (reference Seoul)
       'province' = 15 units (Seoul+Incheon+Gyeonggi merged into the Capital Area)
       'macro'    = SMA / Chungcheong / Jeolla / Gyeongsang (Gangwon and Jeju not shown; they stay in national totals)
Data: Anthropic Economic Index release 2026-06-26 (Claude.ai, Apr+May 2026 avg); Regional Employment Survey H2 2025
(employed, 시도가중값; region = workplace); KEDI enrollment 1 Apr 2025; KSCO-8 2-digit -> SOC major first-guess crosswalk.
Usage: python3 make_figures.py <mode> <aei_csv> <micro_pkl> <crosswalk_csv> <enrollment_csv> <outdir>
"""
import sys, os, numpy as np, pandas as pd, matplotlib, statsmodels.formula.api as smf
matplotlib.use('Agg'); import matplotlib.pyplot as plt
mode, aei_csv, micro_pkl, xw_csv, enr_csv, outdir = sys.argv[1:7]
os.makedirs(outdir, exist_ok=True)

PROV = {'11':'Seoul','21':'Busan','22':'Daegu','23':'Incheon','24':'Gwangju','25':'Daejeon','26':'Ulsan','29':'Sejong',
        '31':'Gyeonggi','32':'Gangwon','33':'Chungbuk','34':'Chungnam','35':'Jeonbuk','36':'Jeonnam','37':'Gyeongbuk',
        '38':'Gyeongnam','39':'Jeju'}
AEI2PROV = {'KR-11':'Seoul','KR-26':'Busan','KR-27':'Daegu','KR-28':'Incheon','KR-29':'Gwangju','KR-30':'Daejeon',
            'KR-31':'Ulsan','KR-50':'Sejong','KR-41':'Gyeonggi','KR-42':'Gangwon','KR-43':'Chungbuk','KR-44':'Chungnam',
            'KR-45':'Jeonbuk','KR-46':'Jeonnam','KR-47':'Gyeongbuk','KR-48':'Gyeongnam','KR-49':'Jeju'}
CAP = {'Seoul','Incheon','Gyeonggi'}
if mode == 'province':
    UNIT = {p: ('Capital Area' if p in CAP else p) for p in PROV.values()}
    REF = 'Capital Area'; SHOW = None
elif mode == 'province17':
    UNIT = {p: p for p in PROV.values()}
    REF = 'Seoul'; SHOW = None
else:
    MAC = {'SMA': ['Seoul','Incheon','Gyeonggi'], 'Chungcheong': ['Chungbuk','Chungnam','Daejeon','Sejong'],
           'Jeolla': ['Jeonbuk','Jeonnam','Gwangju'], 'Gyeongsang': ['Gyeongbuk','Gyeongnam','Busan','Ulsan','Daegu']}
    UNIT = {p: m for m, ps in MAC.items() for p in ps}; UNIT.update({'Gangwon': 'Gangwon', 'Jeju': 'Jeju'})
    REF = 'SMA'; SHOW = list(MAC)
units_all = list(dict.fromkeys(UNIT.values()))
RL = REF if mode == 'province17' else f'the {REF}'   # reference label for titles

# ---------------- AEI ----------------
d = pd.read_csv(aei_csv)
d = d[d.geo_id.isin(list(AEI2PROV) + ['KOR'])]
d['prov'] = d.geo_id.map(AEI2PROV).fillna('KOR')
ov = d[(d.category_name=='overall') & (d.geo_id!='KOR')].groupby(['prov','metric_id']).value.mean().unstack()
usage = ov.usage_pct
work = usage * ov.use_case_work_pct
cw = usage * ov.use_case_coursework_pct
agg = lambda s: s.groupby(UNIT).sum()
usage_u, work_u, cw_u = agg(usage), 100*agg(work)/work.sum(), 100*agg(cw)/cw.sum()
lab = d[(d.category_name=='soc_occupation') & (d.hierarchy_level==1)][['node_external_id','node_name']].drop_duplicates()
SOC = dict(zip(lab.node_name, lab.node_external_id.str[:2])); SOCNAME = {v: k for k, v in SOC.items()}
occ = d[(d.category_name=='soc_occupation') & (d.hierarchy_level==1) & (d.metric_id=='pct')].copy()
occ['soc'] = occ.node_name.map(SOC)
occ = occ.groupby(['geo_id','prov','soc']).value.mean().reset_index()
kor = occ[occ.geo_id=='KOR'].set_index('soc').value
reg = occ[occ.geo_id!='KOR'].copy()
reg['U'] = reg.prov.map(usage) * reg.value / 100
reg['unit'] = reg.prov.map(UNIT)
U = reg.groupby(['unit','soc']).U.sum().unstack()

# ---------------- survey ----------------
m = pd.read_pickle(micro_pkl)
m['w'] = m['시도가중값'].astype(float)
e = m[m['경제활동구분코드']=='1'].copy()
e['unit'] = e['사업체직장소재지_행정구역코드'].map(PROV).map(UNIT)
e = e[e.unit.notna()]
xw = pd.read_csv(xw_csv, dtype={'ksco8_2d':str,'soc_major_1':str,'soc_major_2':str})
alloc = pd.concat([xw[['ksco8_2d','soc_major_1','weight_1']].set_axis(['occ','soc','a'],axis=1),
                   xw[['ksco8_2d','soc_major_2','weight_2']].set_axis(['occ','soc','a'],axis=1)]).dropna()
e['occ'] = e['2자리_8차직업중분류코드']
g = e.groupby(['unit','occ']).w.sum().reset_index().merge(alloc, on='occ')
g['emp'] = g.w * g.a
E = g.pivot_table(index='unit', columns='soc', values='emp', aggfunc='sum').fillna(0)
emp_share = 100 * E.sum(1) / E.values.sum()
P = E.div(E.sum()).mul(kor.reindex(E.columns))                     # equal-intensity benchmark
I = U.reindex(index=E.index, columns=E.columns) / P                 # within-occupation intensity

res = pd.DataFrame({'usage_share': usage_u, 'employment_share': emp_share, 'work_usage_share': work_u})
res['work_usage_per_worker'] = res.work_usage_share / res.employment_share
res['usage_per_worker_unadjusted'] = res.usage_share / res.employment_share
res['usage_occupation_adjusted'] = res.usage_share / P.sum(1)

# wage and education gaps within occupation (occupation FE), relative to REF
e['unit_c'] = pd.Categorical(e.unit, categories=[REF] + [u for u in units_all if u != REF])
e['degree'] = pd.to_numeric(e['학력코드'], errors='coerce').ge(5).astype(float)
grp = pd.factorize(e['가구단위일련번호'])[0]
r_ed = smf.wls('degree ~ C(unit_c) + C(occ)', data=e, weights=e.w).fit(cov_type='cluster', cov_kwds={'groups': grp})
base_ed = np.average(r_ed.fittedvalues - sum(r_ed.params.get(f'C(unit_c)[T.{u}]', 0)*(e.unit==u) for u in units_all), weights=e.w)
ww = e[e['현직장종사상지위코드'].isin(['1','2'])].copy()
ww['wage'] = pd.to_numeric(ww['최근3개월_월평균급여'], errors='coerce'); ww['hours'] = pd.to_numeric(ww['조사대상주간_주업근무시간수'], errors='coerce')
ww = ww[(ww.wage>0) & (ww.hours>0)]; ww['hw'] = ww.wage/(ww.hours*4.345)
lo, hi = ww.hw.quantile([.005,.995]); ww = ww[ww.hw.between(lo,hi)]; ww['lhw'] = np.log(ww.hw)
r_w = smf.wls('lhw ~ C(unit_c) + C(occ)', data=ww, weights=ww.w).fit(cov_type='cluster', cov_kwds={'groups': pd.factorize(ww['가구단위일련번호'])[0]})
gap = pd.DataFrame(index=units_all)
gap['ai_rel'] = res.usage_occupation_adjusted / res.usage_occupation_adjusted[REF]
gap['wage_rel'] = [np.exp(r_w.params.get(f'C(unit_c)[T.{u}]', 0)) for u in units_all]
gap['degree_share_occ_adj'] = [base_ed + r_ed.params.get(f'C(unit_c)[T.{u}]', 0) for u in units_all]
gap['education_rel'] = gap.degree_share_occ_adj / gap.degree_share_occ_adj[REF]

# worker age: occupation-adjusted gap (years) and age-controlled wage / education gaps
e['age'] = pd.to_numeric(e['만연령'], errors='coerce'); ww['age'] = pd.to_numeric(ww['만연령'], errors='coerce')
e['age2'] = e.age**2/100; ww['age2'] = ww.age**2/100
cl = lambda df: {'groups': pd.factorize(df['가구단위일련번호'])[0]}
r_age = smf.wls('age ~ C(unit_c) + C(occ)', data=e, weights=e.w).fit(cov_type='cluster', cov_kwds=cl(e))
coef = lambda r, u: r.params.get(f'C(unit_c)[T.{u}]', 0)
se = lambda r, u: r.bse.get(f'C(unit_c)[T.{u}]', 0)
wmean_age = e.groupby('unit').apply(lambda x: np.average(x.age, weights=x.w), include_groups=False)
gap['age_diff_occ_adj_years'] = [coef(r_age, u) for u in units_all]
gap['age_diff_occ_adj_se'] = [se(r_age, u) for u in units_all]
gap['age_diff_raw_years'] = [wmean_age[u] - wmean_age[REF] for u in units_all]
gap['mean_age_raw'] = [wmean_age[u] for u in units_all]
r_w2 = smf.wls('lhw ~ C(unit_c) + C(occ) + age + age2', data=ww, weights=ww.w).fit(cov_type='cluster', cov_kwds=cl(ww))
r_ed2 = smf.wls('degree ~ C(unit_c) + C(occ) + age + age2', data=e, weights=e.w).fit(cov_type='cluster', cov_kwds=cl(e))
base_ed2 = np.average(r_ed2.fittedvalues - sum(coef(r_ed2, u)*(e.unit==u) for u in units_all), weights=e.w)
gap['wage_rel_age_ctrl'] = [np.exp(coef(r_w2, u)) for u in units_all]
gap['education_rel_age_ctrl'] = [(base_ed2 + coef(r_ed2, u)) / base_ed2 for u in units_all]

# students
enr = pd.read_csv(enr_csv).set_index('province').drop('South Korea')
enr['base'] = enr[['high','undergraduate','masters','doctoral']].sum(1)
enr['higher_ed'] = enr[['undergraduate','masters','doctoral']].sum(1)
eu = enr[['base','higher_ed']].groupby(UNIT).sum()
res['coursework_usage_share'] = cw_u
res['coursework_per_student'] = cw_u / (100*eu.base/eu.base.sum())
res['coursework_per_higher_ed_student'] = cw_u / (100*eu.higher_ed/eu.higher_ed.sum())
res = res.join(gap)

show = SHOW or units_all
res_s = res.loc[show]
order = res_s.work_usage_per_worker.sort_values().index.tolist()   # bottom-to-top for barh

# ---------------- styling ----------------
BLUE, ORANGE, AQUA, GRAY, INK, INK2, GRID, BG = '#2a78d6', '#eb6834', '#1baf7a', '#8f8e88', '#0b0b0b', '#52514e', '#e6e5e0', '#fcfcfb'
plt.rcParams.update({'font.size': 8, 'axes.edgecolor': BG, 'text.color': INK, 'axes.labelcolor': INK2,
                     'xtick.color': INK2, 'ytick.color': INK, 'figure.facecolor': BG, 'axes.facecolor': BG})
SRC = {'aei': 'Claude.ai usage: Anthropic Economic Index (Apr–May 2026).',
       'emp': 'Employment: Regional Employment Survey H2 2025, by workplace.',
       'enr': 'Students: KEDI enrollment, Apr 2025 (high school + higher education).'}
tag = {'province': 'provinces', 'province17': 'provinces17', 'macro': 'macro'}[mode]
unit_note = ('Capital Area = Seoul + Incheon + Gyeonggi.' if mode == 'province' else
             '17 provinces, no aggregation. IP-based location may shift usage within the capital region towards Seoul.' if mode == 'province17'
             else 'SMA = Seoul, Incheon, Gyeonggi; Chungcheong = Chungbuk, Chungnam, Daejeon, Sejong; Jeolla = Jeonbuk, Jeonnam, Gwangju;\nGyeongsang = Gyeongbuk, Gyeongnam, Busan, Ulsan, Daegu. Gangwon and Jeju not shown (kept in national totals).')
H = max(0.32*len(order) + 1.6, 3.4)

def finish(fig, ax, title, sub, notes, fname, pad=22, sub_y=1.02, legend=None):
    """Fixed-inch layout: title, subtitle, optional legend row, plot, notes."""
    fh = fig.get_figheight()
    nlines = sum(n.count('\n') + 1 for n in notes)
    top_in = 0.72 + (0.28 if legend else 0)
    fig.subplots_adjust(bottom=(0.55 + 0.12*nlines)/fh, top=1 - top_in/fh)
    x0 = ax.get_position().x0
    fig.text(x0, 1 - 0.12/fh, title, fontsize=11, color=INK, va='top', ha='left')
    fig.text(x0, 1 - 0.40/fh, sub, fontsize=8, color=INK2, va='top', ha='left')
    if legend:
        h, l = ax.get_legend_handles_labels()
        fig.legend(h, l, loc='upper left', bbox_to_anchor=(x0 - 0.01, 1 - 0.58/fh), ncol=len(l), frameon=False,
                   fontsize=7.5, handletextpad=0.3, columnspacing=1.2)
    fig.text(0.01, 0.06/fh, '\n'.join(notes), fontsize=6.5, color=INK2, va='bottom')
    for s_ in ax.spines.values(): s_.set_visible(False)
    fig.savefig(f'{outdir}/{fname}', dpi=200, bbox_inches='tight', facecolor=BG); plt.close(fig)

def bars(col, title, sub, notes, fname, alt=None, alt_label=None):
    fig, ax = plt.subplots(figsize=(7, H))
    v = res_s.loc[order, col]; y = np.arange(len(order))
    ax.barh(y, v, height=0.62, color=BLUE, zorder=2)
    a = res_s.loc[order, alt] if alt is not None else v
    xmax_ = max(v.max(), a.max())
    for yi, val, av in zip(y, v, a): ax.text(max(val, av) + 0.025*xmax_ + 0.01, yi, f'{val:.2f}', va='center', fontsize=7.5, color=INK)
    if alt is not None:
        ax.scatter(a, y, s=28, facecolor=BG, edgecolor=INK, linewidth=1.2, zorder=3, label=alt_label)
        ax.legend(frameon=False, loc='lower right', fontsize=7.5)
    ax.axvline(1, color=INK2, lw=0.9, ls=(0, (4, 3)), zorder=1)
    ax.set_yticks(y, order); ax.tick_params(length=0)
    ax.grid(axis='x', color=GRID, lw=0.7, zorder=0); ax.set_xlim(0, max(v.max(), (res_s[alt].max() if alt else 0))*1.15)
    finish(fig, ax, title, sub, notes, fname)

# F1 work usage per worker
bars('work_usage_per_worker', 'Work use of Claude per worker',
     'Share of Korean work-related usage ÷ share of employment (1 = proportional)',
     [SRC['aei'] + ' ' + SRC['emp'], unit_note], f'{tag}_1_work_usage_per_worker.png')

# F2 dumbbell unadjusted vs occupation-adjusted
fig, ax = plt.subplots(figsize=(7, H)); y = np.arange(len(order))
a = res_s.loc[order, 'usage_per_worker_unadjusted']; b = res_s.loc[order, 'usage_occupation_adjusted']
ax.hlines(y, np.minimum(a, b), np.maximum(a, b), color=GRID, lw=3, zorder=1)
ax.scatter(a, y, s=40, color=GRAY, edgecolor=BG, linewidth=1.5, zorder=3, label='Unadjusted (usage ÷ employment)')
ax.scatter(b, y, s=40, color=BLUE, edgecolor=BG, linewidth=1.5, zorder=4, label='Adjusted for occupation mix')
for yi, val in zip(y, b): ax.text(max(val, a.iloc[yi]) + 0.05, yi, f'{val:.2f}', va='center', fontsize=7.5)
ax.axvline(1, color=INK2, lw=0.9, ls=(0, (4, 3)), zorder=0)
ax.set_yticks(y, order); ax.tick_params(length=0); ax.grid(axis='x', color=GRID, lw=0.7, zorder=0)
ax.set_xlim(0, max(a.max(), b.max())*1.15); ax.legend(frameon=False, loc='lower right', fontsize=7.5)
finish(fig, ax, 'Claude usage per worker, before and after accounting for occupations',
       'All usage; adjusted = usage share ÷ usage share expected from the region’s occupation mix (1 = national rate)',
       [SRC['aei'] + ' ' + SRC['emp'], 'Occupation = SOC major group of the task (KSCO-8 crosswalk). ' + unit_note],
       f'{tag}_2_usage_unadjusted_vs_occupation_adjusted.png')

# F3 within-occupation intensity, small multiples
SEL = ['15','27','25','43','13','41']
cols = 3; rows = 2
fig, axes = plt.subplots(rows, cols, figsize=(9.5, 0.27*len(order)*rows + 2.2), sharey=True, sharex=True)
xmax = np.nanmax(I.loc[show, SEL].values) * 1.12
for k, s in enumerate(SEL):
    ax = axes.flat[k]; v = I.loc[order, s]; yy = np.arange(len(order))
    ax.barh(yy, v.fillna(0), height=0.62, color=BLUE, zorder=2)
    for yi, val in zip(yy, v):
        ax.text((0 if np.isnan(val) else val) + 0.04, yi, 'n/a' if np.isnan(val) else f'{val:.2f}', va='center', fontsize=6.5)
    ax.axvline(1, color=INK2, lw=0.9, ls=(0, (4, 3)), zorder=1)
    ax.set_title(SOCNAME[s].replace(', Sports, and Media', '/Media').replace(' and Library', '').replace(' Operations', ''),
                 loc='left', fontsize=8.5, color=INK)
    ax.set_yticks(yy, order); ax.tick_params(length=0); ax.grid(axis='x', color=GRID, lw=0.7, zorder=0)
    ax.set_xlim(0, xmax); [sp.set_visible(False) for sp in ax.spines.values()]
fig.text(0.01, 0.995, 'Claude usage within occupations, by region', ha='left', va='top', fontsize=11, color=INK)
fig.text(0.01, 0.995 - 0.35/fig.get_figheight(), va='top', s= 'Usage of tasks in each occupation group ÷ expected from the region’s employment in it (1 = national rate)',
         fontsize=8, color=INK2)
fig.text(0.01, 0.005, SRC['aei'] + ' ' + SRC['emp'] + '\n' + unit_note, fontsize=6.5, color=INK2)
fig.tight_layout(rect=(0, 0.6/fig.get_figheight(), 1, 1 - 0.6/fig.get_figheight())); fig.savefig(f'{outdir}/{tag}_3_within_occupation_intensity.png', dpi=200, facecolor=BG); plt.close(fig)

# F4 gaps relative to reference, within occupation
others = [u for u in order if u != REF][::-1]; others = others[::-1]
fig, ax = plt.subplots(figsize=(7, max(0.34*len(others) + 1.8, 3.4))); yy = np.arange(len(others))
for col, c, lab_, off in [('ai_rel', BLUE, 'Claude usage', 0.18), ('wage_rel', ORANGE, 'Hourly wage', 0), ('education_rel', AQUA, 'University degree share', -0.18)]:
    v = gap.loc[others, col]
    ax.scatter(v, yy + off, s=34, color=c, edgecolor=BG, linewidth=1.2, zorder=3, label=lab_)
ax.axvline(1, color=INK2, lw=0.9, ls=(0, (4, 3)), zorder=1)
ax.set_xscale('log'); ticks = [0.1, 0.2, 0.3, 0.5, 0.7, 1, 1.5]
ax.set_xticks(ticks, [f'{t:g}' for t in ticks]); ax.minorticks_off()
ax.set_xlim(min(0.09, gap.loc[others, ['ai_rel','wage_rel','education_rel']].min().min()*0.85), max(1.6, gap.loc[others, ['ai_rel','wage_rel','education_rel']].max().max()*1.1))
ax.set_yticks(yy, others); ax.tick_params(length=0); ax.grid(axis='x', color=GRID, lw=0.7, zorder=0)
finish(fig, ax, f'Gaps to {RL} within the same occupation',
       f'Ratio to {RL} (1 = same as {RL}; log scale), each controlling for occupation only',
       ['Claude: occupation-adjusted usage index relative to the reference. Wage: exp(region coefficient), log hourly wage on region + KSCO-8 2-digit FE.',
        'Degree share: 4-year university or higher, linear probability model on region + occupation FE, evaluated at the national occupation mix.',
        SRC['aei'] + ' ' + SRC['emp'], unit_note], f'{tag}_4_gaps_vs_reference.png', legend=True)

# F6 average worker age vs reference, within occupation
fig, ax = plt.subplots(figsize=(7, max(0.34*len(others) + 1.8, 3.4))); yy = np.arange(len(others))
va_ = gap.loc[others, 'age_diff_occ_adj_years']; ser_ = gap.loc[others, 'age_diff_occ_adj_se']; vr_ = gap.loc[others, 'age_diff_raw_years']
ax.hlines(yy, va_ - 1.96*ser_, va_ + 1.96*ser_, color=BLUE, lw=1.2, alpha=0.5, zorder=2)
ax.scatter(vr_, yy, s=30, facecolor=BG, edgecolor=INK, linewidth=1.1, zorder=3, label='Raw difference')
ax.scatter(va_, yy, s=38, color=BLUE, edgecolor=BG, linewidth=1.2, zorder=4, label='Same occupation (95% CI)')
for yi, val in zip(yy, va_): ax.text(max(val + 1.96*ser_.iloc[yi], vr_.iloc[yi]) + 0.3, yi, f'{val:+.1f}  (raw {vr_.iloc[yi]:+.1f})', va='center', fontsize=7.5)
ax.axvline(0, color=INK2, lw=0.9, ls=(0, (4, 3)), zorder=1)
ax.set_yticks(yy, others); ax.tick_params(length=0); ax.grid(axis='x', color=GRID, lw=0.7, zorder=0)
ax.set_xlim(min(-1, (va_ - 2*ser_).min(), vr_.min()) - 0.5, max((va_ + 2*ser_).max(), vr_.max()) + 2.6)
ax.set_xlabel('Years older (+) or younger (−) than ' + RL, fontsize=7.5, color=INK2)
finish(fig, ax, f'Average worker age compared with {RL}',
       f'Difference in mean age of employed workers, raw and within the same occupation (KSCO-8 2-digit FE)',
       [SRC['emp'] + f' {REF} mean age: {wmean_age[REF]:.1f} years. Weighted (시도가중값), SEs clustered by household.', unit_note],
       f'{tag}_6_worker_age_vs_reference.png', legend=True)

# F5 coursework per student
bars('coursework_per_student', 'Coursework use of Claude per student',
     'Share of Korean coursework usage ÷ share of enrolled students (1 = proportional)',
     [SRC['aei'] + ' ' + SRC['enr'], 'Hollow marker: higher-education students only (Claude.ai requires users to be 18+). Students counted at institution location.', unit_note],
     f'{tag}_5_coursework_per_student.png', alt='coursework_per_higher_ed_student', alt_label='Higher-education students only')

# data
with pd.ExcelWriter(f'{outdir}/{tag}_figure_data.xlsx') as xl:
    pd.DataFrame({'note': [__doc__]}).to_excel(xl, 'README', index=False)
    res.round(4).to_excel(xl, 'regional_indicators')
    I.rename(columns=lambda s: f'{s} {SOCNAME.get(s, "")}').round(3).to_excel(xl, 'within_occupation_intensity')
    E.rename(columns=lambda s: f'{s} {SOCNAME.get(s, "")}').round(0).to_excel(xl, 'employment_by_soc')
pd.set_option('display.width', 250)
print(res_s[['ai_rel','wage_rel','wage_rel_age_ctrl','education_rel','education_rel_age_ctrl','mean_age_raw','age_diff_raw_years','age_diff_occ_adj_years','age_diff_occ_adj_se']].round(2).to_string())
print(I.loc[show, SEL].rename(columns=SOCNAME).round(2).to_string())
