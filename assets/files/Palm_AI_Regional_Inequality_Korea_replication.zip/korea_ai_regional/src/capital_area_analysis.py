"""All Korea regional analyses with Seoul, Incheon and Gyeonggi merged into one Seoul Capital Area (수도권) unit.

Units: Capital Area + 14 other provinces/metropolitan cities (15 units).
AEI side (release 2026-06-26, average of Apr & May 2026):
  - usage shares are summed across the three capital-area provinces;
  - overall metrics (pcts and means) are usage-share-weighted averages of the provincial values;
  - occupation cells: U[r,s] = usage_pct * pct / 100 summed across provinces (suppressed sub-cells count as 0, flagged).
Survey side (Regional Employment Survey H2 2025, 시도가중값): provinces mapped to units before summing.
Usage: python3 capital_area_analysis.py <aei_dir> <wage_dir> <crosswalk_csv> <out_xlsx>
"""
import sys, pandas as pd, numpy as np
aei_dir, wage_dir, xw_path, out = sys.argv[1:5]

AEI2REG = {'KR-11':'11','KR-26':'21','KR-27':'22','KR-28':'23','KR-29':'24','KR-30':'25','KR-31':'26','KR-50':'29',
           'KR-41':'31','KR-42':'32','KR-43':'33','KR-44':'34','KR-45':'35','KR-46':'36','KR-47':'37','KR-48':'38','KR-49':'39'}
NAME = {'11':'Seoul','21':'Busan','22':'Daegu','23':'Incheon','24':'Gwangju','25':'Daejeon','26':'Ulsan','29':'Sejong',
        '31':'Gyeonggi','32':'Gangwon','33':'Chungbuk','34':'Chungnam','35':'Jeonbuk','36':'Jeonnam','37':'Gyeongbuk',
        '38':'Gyeongnam','39':'Jeju'}
CAPITAL = {'11','23','31'}
UNIT = {k: ('Capital Area' if k in CAPITAL else v) for k, v in NAME.items()}
UNITS = ['Capital Area'] + [v for k, v in NAME.items() if k not in CAPITAL]

# ---------------- AEI ----------------
d = pd.read_csv(f'{aei_dir}/aei_claude_ai_2026-06-26.csv')
d = d[d.geo_id.isin(list(AEI2REG) + ['KOR'])]
d['unit'] = d.geo_id.map(lambda g: UNIT[AEI2REG[g]] if g in AEI2REG else 'Korea')

ov = d[d.category_name == 'overall'].groupby(['geo_id', 'unit', 'metric_id']).value.mean().unstack()
w = ov.usage_pct
metrics = ov.drop(columns='usage_pct')
overall = (metrics.mul(w, axis=0).groupby(level='unit').sum()
           .div(metrics.notna().mul(w, axis=0).groupby(level='unit').sum()))
overall.insert(0, 'usage_pct', w.groupby(level='unit').sum())
overall = overall.reindex(UNITS + ['Korea'])
overall.loc['Korea', 'usage_pct'] = 100.0   # national row: 100% of Korean usage (not Korea's global share)
# NB: means like time/education are averaged with usage weights, an approximation where the
# metric is defined on a sub-population (e.g. conversations with a classified task).

soc_lab = d[(d.category_name == 'soc_occupation') & (d.hierarchy_level == 1)][['node_external_id', 'node_name']].drop_duplicates()
SOC = dict(zip(soc_lab.node_name, soc_lab.node_external_id.str[:2]))
SOCNAME = {v: k for k, v in SOC.items()}
occ = d[(d.category_name == 'soc_occupation') & (d.hierarchy_level == 1) & (d.metric_id == 'pct')].copy()
occ['soc'] = occ.node_name.map(SOC)
occ = occ.groupby(['geo_id', 'unit', 'soc']).value.mean().reset_index()
kor = occ[occ.geo_id == 'KOR'].set_index('soc').value
reg = occ[occ.geo_id != 'KOR'].copy()
reg['U'] = reg.geo_id.map(w.droplevel('unit')) * reg.value / 100
U = reg.groupby(['unit', 'soc']).U.sum().unstack().reindex(UNITS)
# flag capital-area cells where a member province was suppressed
cap_n = reg[reg.unit == 'Capital Area'].groupby('soc').geo_id.nunique()
U = U.where(~U.isna(), np.nan)

# ---------------- survey ----------------
m = pd.read_pickle(f'{wage_dir}/micro.pkl')
m['w'] = m['시도가중값'].astype(float)
m['age'] = pd.to_numeric(m['만연령'], errors='coerce')
m['unit_res'] = m['2자리_행정구역시도코드'].map(UNIT)
m['unit_work'] = m['사업체직장소재지_행정구역코드'].map(UNIT)
e = m[m['경제활동구분코드'] == '1']
xw = pd.read_csv(xw_path, dtype={'ksco8_2d': str, 'soc_major_1': str, 'soc_major_2': str})
alloc = pd.concat([xw[['ksco8_2d', 'soc_major_1', 'weight_1']].set_axis(['ksco', 'soc', 'a'], axis=1),
                   xw[['ksco8_2d', 'soc_major_2', 'weight_2']].set_axis(['ksco', 'soc', 'a'], axis=1)]).dropna()

def emp_by_soc(unitcol):
    g = e.groupby([unitcol, '2자리_8차직업중분류코드']).w.sum().reset_index()
    g.columns = ['unit', 'ksco', 'emp']
    g = g.merge(alloc, on='ksco'); g['emp'] *= g.a
    return g.pivot_table(index='unit', columns='soc', values='emp', aggfunc='sum').reindex(UNITS).fillna(0)

occ_out, tot_out = {}, {}
for label in ['workplace', 'residence']:
    E = emp_by_soc(f'unit_{label[:4] if label=="workplace" else "res"}')
    P = E.div(E.sum()).mul(kor.reindex(E.columns))
    I = U.reindex(columns=P.columns) / P
    tot = pd.DataFrame({'usage_share_actual': overall.usage_pct.reindex(UNITS),
                        'employment_share': 100 * E.sum(1) / E.values.sum(),
                        'usage_share_if_equal_intensity': P.sum(1)})
    tot['ratio_actual_to_equal_intensity'] = tot.usage_share_actual / tot.usage_share_if_equal_intensity
    occ_out[label] = dict(E=E, P=P, I=I); tot_out[label] = tot

# use cases
S = pd.DataFrame({c: overall.usage_pct * overall[f'use_case_{c}_pct'] for c in ['work', 'personal', 'coursework']}).reindex(UNITS)
S = 100 * S / S.sum()
B = pd.DataFrame({'work': e.groupby('unit_work').w.sum(),
                  'personal': m[m.age.between(15, 64)].groupby('unit_res').w.sum(),
                  'coursework': m[(m['교육정도_수학구분코드'] == '2') & (pd.to_numeric(m['학력코드'], errors='coerce') >= 3)].groupby('unit_res').w.sum()}).reindex(UNITS)
B = 100 * B / B.sum()
uc = S.join(B, lsuffix='_usage_share', rsuffix='_benchmark_share')
for c in ['work', 'personal', 'coursework']:
    uc[f'{c}_ratio'] = uc[f'{c}_usage_share'] / uc[f'{c}_benchmark_share']

# ---------------- output ----------------
order = kor.sort_values(ascending=False).index
named = lambda df: df.rename(columns=lambda s: f'{s} {SOCNAME.get(s, "")}')
with pd.ExcelWriter(out) as xl:
    pd.DataFrame({'note': [
        'Capital Area = Seoul + Incheon + Gyeonggi; 15 regional units in total.',
        'AEI release 2026-06-26, average of Apr & May 2026. Overall metrics for the Capital Area are usage-weighted averages of the three provinces.',
        'U = observed share of total Korean usage (%) by unit x SOC major group. P = equal-intensity benchmark. I = U/P (1 = proportional to employment).',
        'Use-case benchmarks: work -> employment by workplace; personal -> population 15-64 by residence; coursework -> enrolled students by residence.',
        'Survey: Regional Employment Survey H2 2025, weighted with 시도가중값. KSCO-8 2-digit -> SOC via first-guess crosswalk.',
        f'Capital-area occupation cells built from fewer than 3 provinces (suppression): {", ".join(SOCNAME[s] for s, n in cap_n.items() if n < 3) or "none"}.']}
    ).to_excel(xl, 'README', index=False)
    overall.T.round(2).to_excel(xl, 'overall_metrics')
    for label in tot_out:
        tot_out[label].round(3).to_excel(xl, f'totals_{label}')
        named(occ_out[label]['I'][order]).round(2).to_excel(xl, f'intensity_{label}')
    named(U[order]).round(3).to_excel(xl, 'U_observed')
    uc.round(3).to_excel(xl, 'use_case')
    longs = []
    for label in occ_out:
        o = occ_out[label]
        L = pd.concat({'U': U.reindex(columns=o['P'].columns).stack(future_stack=True), 'P': o['P'].stack(),
                       'E': o['E'].stack(), 'I': o['I'].stack(future_stack=True)}, axis=1).reset_index()
        L['region_def'] = label; longs.append(L)
    long = pd.concat(longs); long['soc_label'] = long.soc.map(SOCNAME)
    long.to_excel(xl, 'long', index=False)
long.to_csv(out.replace('.xlsx', '_long.csv'), index=False)

pd.set_option('display.width', 250)
print(tot_out['workplace'].round(2).to_string())
print(uc[[f'{c}_ratio' for c in ['work', 'personal', 'coursework']]].round(2).to_string())
top = list(order[:8])
print(occ_out['workplace']['I'][top].rename(columns=SOCNAME).round(2).to_string())
print(overall[['usage_pct', 'use_case_work_pct', 'collaboration_bucket_automation_pct', 'human_education_years_mean', 'ai_autonomy_mean', 'artifact_translation_pct']].round(2).to_string())
print('cap cells w/ suppression:', cap_n[cap_n < 3].to_dict())
