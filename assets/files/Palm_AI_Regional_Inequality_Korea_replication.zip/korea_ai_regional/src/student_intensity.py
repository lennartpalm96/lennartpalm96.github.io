"""AI coursework usage intensity per student by region.

Coursework usage share of region r: C[r] = usage_pct[r] * use_case_coursework_pct[r], normalised to 100 over Korea
(AEI release 2026-06-26, average of Apr & May 2026).
Students (KEDI, enrollment as of 1 Apr 2025, by institution location):
  base     = high + undergraduate + masters + doctoral
  extended = base + middle
  higher_ed = undergraduate + masters + doctoral (Claude.ai requires users to be 18+, so most high-school students are excluded)
Intensity = coursework usage share / student share (1 = proportional to enrollment).
Reported for 17 provinces and with Seoul + Incheon + Gyeonggi merged into the Capital Area.
Usage: python3 student_intensity.py <aei_dir> <enrollment_csv> <out_xlsx>
"""
import sys, pandas as pd
aei_dir, enr_path, out = sys.argv[1:4]
AEI = {'KR-11':'Seoul','KR-26':'Busan','KR-27':'Daegu','KR-28':'Incheon','KR-29':'Gwangju','KR-30':'Daejeon','KR-31':'Ulsan',
       'KR-50':'Sejong','KR-41':'Gyeonggi','KR-42':'Gangwon','KR-43':'Chungbuk','KR-44':'Chungnam','KR-45':'Jeonbuk',
       'KR-46':'Jeonnam','KR-47':'Gyeongbuk','KR-48':'Gyeongnam','KR-49':'Jeju'}
CAP = {'Seoul','Incheon','Gyeonggi'}
ORDER = list(dict.fromkeys(AEI.values()))

d = pd.read_csv(f'{aei_dir}/aei_claude_ai_2026-06-26.csv')
d = d[(d.category_name=='overall') & d.geo_id.isin(AEI) & d.metric_id.isin(['usage_pct','use_case_coursework_pct'])]
v = d.groupby(['geo_id','metric_id']).value.mean().unstack().rename(index=AEI)
cw = v.usage_pct * v.use_case_coursework_pct

enr = pd.read_csv(enr_path).set_index('province').drop('South Korea')
enr['base'] = enr[['high','undergraduate','masters','doctoral']].sum(1)
enr['extended'] = enr.base + enr.middle
enr['higher_ed'] = enr[['undergraduate','masters','doctoral']].sum(1)

def table(group):
    g = lambda s: s.groupby(group).sum()
    t = pd.DataFrame({'coursework_usage_share': 100*g(cw)/cw.sum(),
                      'students_base': g(enr.base), 'students_extended': g(enr.extended), 'students_higher_ed': g(enr.higher_ed),
                      'higher_ed_share_of_base_pct': 100*g(enr[['undergraduate','masters','doctoral']].sum(1))/g(enr.base)})
    t['student_share_base'] = 100*t.students_base/t.students_base.sum()
    t['student_share_extended'] = 100*t.students_extended/t.students_extended.sum()
    t['intensity_base'] = t.coursework_usage_share/t.student_share_base
    t['intensity_extended'] = t.coursework_usage_share/t.student_share_extended
    t['student_share_higher_ed'] = 100*t.students_higher_ed/t.students_higher_ed.sum()
    t['intensity_higher_ed_only'] = t.coursework_usage_share/t.student_share_higher_ed
    return t

prov = table(lambda r: r).reindex(ORDER)
unit = lambda r: 'Capital Area' if r in CAP else r
cap = table(unit).reindex(['Capital Area'] + [r for r in ORDER if r not in CAP])
block = table(lambda r: 'Capital Area' if r in CAP else 'Rest of Korea')

with pd.ExcelWriter(out) as xl:
    pd.DataFrame({'note': [__doc__]}).to_excel(xl, 'README', index=False)
    cap.round(3).to_excel(xl, 'capital_area_units')
    prov.round(3).to_excel(xl, 'provinces')
    block.round(3).to_excel(xl, 'capital_vs_rest')
pd.set_option('display.width', 250)
cols = ['coursework_usage_share','intensity_base','intensity_extended','intensity_higher_ed_only','higher_ed_share_of_base_pct']
print(cap[cols].round(2).to_string()); print(block[cols].round(2).to_string()); print(prov[cols].round(2).to_string())
