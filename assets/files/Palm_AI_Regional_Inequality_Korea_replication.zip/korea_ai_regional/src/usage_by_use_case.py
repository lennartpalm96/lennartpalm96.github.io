"""Test of the corporate-routing hypothesis: is Seoul's excess larger for work use than for personal/coursework use?

Regional share of Korean usage by use case c:  S[r,c] = usage_pct[r] * c_pct[r] / sum_r(usage_pct[r] * c_pct[r])
Benchmarks (Regional Employment Survey H2 2025, weighted):
  work       -> employed persons by workplace province
  personal   -> population aged 15-64 by residence province
  coursework -> enrolled students (재학, high school or above) by residence province
Ratio = S / benchmark share. Usage: python3 usage_by_use_case.py <aei_dir> <wage_dir> <out_csv>
"""
import sys, pandas as pd
aei_dir, wage_dir, out = sys.argv[1:4]
AEI2REG = {'KR-11':'11','KR-26':'21','KR-27':'22','KR-28':'23','KR-29':'24','KR-30':'25','KR-31':'26','KR-50':'29',
           'KR-41':'31','KR-42':'32','KR-43':'33','KR-44':'34','KR-45':'35','KR-46':'36','KR-47':'37','KR-48':'38','KR-49':'39'}
NAME = {'11':'Seoul','21':'Busan','22':'Daegu','23':'Incheon','24':'Gwangju','25':'Daejeon','26':'Ulsan','29':'Sejong',
        '31':'Gyeonggi','32':'Gangwon','33':'Chungbuk','34':'Chungnam','35':'Jeonbuk','36':'Jeonnam','37':'Gyeongbuk',
        '38':'Gyeongnam','39':'Jeju'}
CAP = {'Seoul','Incheon','Gyeonggi'}

d = pd.read_csv(f'{aei_dir}/aei_claude_ai_2026-06-26.csv')
d = d[(d.category_name=='overall') & d.geo_id.isin(AEI2REG)]
v = d.groupby(['geo_id','metric_id']).value.mean().unstack()      # avg Apr/May
v.index = [NAME[AEI2REG[g]] for g in v.index]
S = pd.DataFrame({c: v.usage_pct * v[f'use_case_{c}_pct'] for c in ['work','personal','coursework']})
S = 100 * S / S.sum()

m = pd.read_pickle(f'{wage_dir}/micro.pkl')
m['w'] = m['시도가중값'].astype(float)
m['age'] = pd.to_numeric(m['만연령'], errors='coerce')
emp = m[m['경제활동구분코드']=='1'].groupby('사업체직장소재지_행정구역코드').w.sum()
pop = m[m.age.between(15,64)].groupby('2자리_행정구역시도코드').w.sum()
stu = m[(m['교육정도_수학구분코드']=='2') & (pd.to_numeric(m['학력코드'],errors='coerce')>=3)].groupby('2자리_행정구역시도코드').w.sum()
B = pd.DataFrame({'work':emp, 'personal':pop, 'coursework':stu})
B = B[B.index.isin(NAME)].rename(index=NAME)
B = 100 * B / B.sum()

res = S.join(B, lsuffix='_usage_share', rsuffix='_benchmark_share')
for c in ['work','personal','coursework']:
    res[f'{c}_ratio'] = res[f'{c}_usage_share'] / res[f'{c}_benchmark_share']
res['work_share_of_region_usage'] = v.use_case_work_pct
res = res.reindex(list(NAME.values()))
cap = res.assign(block=['capital region' if r in CAP else 'rest of Korea' for r in res.index]).groupby('block')[
      [f'{c}_{k}' for c in ['work','personal','coursework'] for k in ['usage_share','benchmark_share']]].sum()
for c in ['work','personal','coursework']:
    cap[f'{c}_ratio'] = cap[f'{c}_usage_share'] / cap[f'{c}_benchmark_share']
pd.concat([res, cap]).round(3).to_csv(out)
pd.set_option('display.width', 250)
print(res[[c+'_usage_share' for c in ['work','personal','coursework']] + [c+'_ratio' for c in ['work','personal','coursework']]].round(2).to_string())
print(cap[[c+'_ratio' for c in ['work','personal','coursework']]].round(2).to_string())
