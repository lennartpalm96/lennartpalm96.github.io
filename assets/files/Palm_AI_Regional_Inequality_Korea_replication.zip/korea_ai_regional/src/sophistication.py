"""Usage sophistication by region: AI autonomy and related Economic Index measures.

Source: Anthropic Economic Index release 2026-06-26 (Claude.ai), province-level overall metrics, April and May 2026.
Regional units are usage-weighted averages of provincial values (weights = usage_pct, per month); the dot is the
Apr/May average, the bar spans the two monthly values. Vertical line = Korea.
Usage: python3 sophistication.py <mode: province|macro> <aei_csv> <figure_data_xlsx (for row order)> <outdir>
"""
import sys, numpy as np, pandas as pd, matplotlib
matplotlib.use('Agg'); import matplotlib.pyplot as plt
mode, aei_csv, order_xlsx, outdir = sys.argv[1:5]
AEI2PROV = {'KR-11':'Seoul','KR-26':'Busan','KR-27':'Daegu','KR-28':'Incheon','KR-29':'Gwangju','KR-30':'Daejeon',
            'KR-31':'Ulsan','KR-50':'Sejong','KR-41':'Gyeonggi','KR-42':'Gangwon','KR-43':'Chungbuk','KR-44':'Chungnam',
            'KR-45':'Jeonbuk','KR-46':'Jeonnam','KR-47':'Gyeongbuk','KR-48':'Gyeongnam','KR-49':'Jeju'}
if mode == 'province':
    UNIT = {p: ('Capital Area' if p in {'Seoul','Incheon','Gyeonggi'} else p) for p in AEI2PROV.values()}; SHOW = None
    note = 'Capital Area = Seoul + Incheon + Gyeonggi.'
elif mode == 'province17':
    UNIT = {p: p for p in AEI2PROV.values()}; SHOW = None
    note = '17 provinces, no aggregation.'
else:
    MAC = {'SMA': ['Seoul','Incheon','Gyeonggi'], 'Chungcheong': ['Chungbuk','Chungnam','Daejeon','Sejong'],
           'Jeolla': ['Jeonbuk','Jeonnam','Gwangju'], 'Gyeongsang': ['Gyeongbuk','Gyeongnam','Busan','Ulsan','Daegu']}
    UNIT = {p: m for m, ps in MAC.items() for p in ps}; SHOW = list(MAC)
    note = 'SMA = Seoul, Incheon, Gyeonggi; Chungcheong = Chungbuk, Chungnam, Daejeon, Sejong; Jeolla = Jeonbuk, Jeonnam, Gwangju; Gyeongsang = Gyeongbuk, Gyeongnam, Busan, Ulsan, Daegu.'

TECH = ['code_fix_or_debug','script_or_snippet','app_or_website','config_or_infra','sql_or_database_query','ml_or_ai_system','data_or_spreadsheet']
d = pd.read_csv(aei_csv)
d = d[(d.category_name=='overall') & d.geo_id.isin(list(AEI2PROV) + ['KOR'])]
w = d.pivot_table(index=['geo_id','date_start'], columns='metric_id', values='value').reset_index()
def derive(x):
    x = x.copy()
    x['speedup'] = x.human_only_time_mean*60 / x.human_with_ai_time_mean
    x['tech_output_pct'] = x[[f'artifact_{t}_pct' for t in TECH]].sum(1)
    x['beyond_human_pct'] = 100 - x.human_only_ability_pct
    return x
METRICS = [('use_case_work_pct','Work use','%'),
           ('ai_autonomy_mean','AI autonomy (1–5)',''),
           ('human_education_years_mean','Education task requires (yrs)',''),
           ('human_only_time_mean','Task length w/o AI (h)',''),
           ('speedup','Speed-up with AI','×'),
           ('collaboration_bucket_automation_pct','Automation share','%'),
           ('tech_output_pct','Technical outputs','%'),
           ('multitasking_pct','Multi-task conversations','%'),
           ('beyond_human_pct','Beyond human ability alone','%')]
cols = [m for m, _, _ in METRICS]
kor = derive(w[w.geo_id=='KOR']).groupby('geo_id')[cols].mean().iloc[0]
p = w[w.geo_id!='KOR'].copy()
p['unit'] = p.geo_id.map(AEI2PROV).map(UNIT)
base = [c for c in p.columns if c not in ('geo_id','date_start','unit')]
def wavg(g):
    ww = g.usage_pct
    return pd.Series({c: np.average(g[c], weights=ww) for c in base if c != 'usage_pct'})
mon = p.groupby(['unit','date_start']).apply(wavg, include_groups=False).reset_index()
mon = derive(mon)
avg = mon.groupby('unit')[cols].mean(); lo_ = mon.groupby('unit')[cols].min(); hi_ = mon.groupby('unit')[cols].max()
show = SHOW or list(avg.index)
fd = pd.read_excel(order_xlsx, 'regional_indicators', index_col=0)
order = fd.loc[show, 'work_usage_per_worker'].sort_values().index.tolist()

BLUE, INK, INK2, GRID, BG = '#2a78d6', '#0b0b0b', '#52514e', '#e6e5e0', '#fcfcfb'
plt.rcParams.update({'font.size': 8, 'figure.facecolor': BG, 'axes.facecolor': BG, 'xtick.color': INK2, 'ytick.color': INK})
n = len(order); rowh = 0.26 if n > 5 else 0.42
rel = lambda df, m: 100*(df.loc[order, m]/kor[m] - 1)
lim = max(25, max(max(rel(lo_, m).abs().max(), rel(hi_, m).abs().max()) for m in cols)*1.12)
fig, axes = plt.subplots(3, 3, figsize=(10, 3*(rowh*n + 0.9) + 1.5), sharey=True, sharex=True)
for ax, (m, lab, unit) in zip(axes.flat, METRICS):
    y = np.arange(n)
    ax.axvspan(-5, 5, color=GRID, alpha=0.45, lw=0, zorder=0)
    ax.hlines(y, rel(lo_, m), rel(hi_, m), color=BLUE, lw=1.4, alpha=0.45, zorder=2)
    ax.scatter(rel(avg, m), y, s=30, color=BLUE, edgecolor=BG, linewidth=1, zorder=3)
    ax.axvline(0, color=INK2, lw=0.9, ls=(0, (4, 3)), zorder=1)
    kv = f'{kor[m]:.1f}%' if unit == '%' else (f'{kor[m]:.2f}×' if unit == '×' else f'{kor[m]:.2f}')
    ax.set_title(f'{lab} — Korea {kv}', loc='left', fontsize=8, color=INK)
    ax.set_yticks(y, order); ax.tick_params(length=0); ax.grid(axis='x', color=GRID, lw=0.7, zorder=0)
    ax.set_ylim(-0.6, n - 0.4); ax.set_xlim(-lim, lim); ax.set_xticks([t for t in (-20, -10, 0, 10, 20) if abs(t) < lim])
    ax.xaxis.set_major_formatter(matplotlib.ticker.FuncFormatter(lambda v, _: f'{v:+.0f}%' if v else '0'))
    for sp in ax.spines.values(): sp.set_visible(False)
fh = fig.get_figheight()
fig.text(0.01, 1 - 0.1/fh, 'How people use Claude, by region', fontsize=11, color=INK, va='top')
fig.text(0.01, 1 - 0.38/fh, '% difference from Korea, usage-weighted regional averages; dot = Apr–May 2026 average, bar = range of the two monthly values; shaded band = ±5%',
         fontsize=8, color=INK2, va='top')
fig.text(0.01, 0.05/fh, 'Anthropic Economic Index (Claude.ai), release 2026-06-26. Task measures are Claude-classified estimates per conversation. Speed-up = mean time without AI ÷ mean time with AI.\n'
         'Technical outputs = code fixes, scripts, apps/websites, config/infra, SQL, ML systems, data/spreadsheets.\n' + note,
         fontsize=6.3, color=INK2, va='bottom')
fig.tight_layout(rect=(0, 0.6/fh, 1, 1 - 0.6/fh))
tag = {'province': 'provinces', 'province17': 'provinces17', 'macro': 'macro'}[mode]
fig.savefig(f'{outdir}/{tag}_7_usage_sophistication.png', dpi=200, facecolor=BG); plt.close(fig)

out = avg.loc[show].copy(); out.loc['Korea'] = kor
with pd.ExcelWriter(f'{outdir}/{tag}_sophistication_data.xlsx') as xl:
    pd.DataFrame({'note': [__doc__]}).to_excel(xl, 'README', index=False)
    out.round(3).to_excel(xl, 'apr_may_average')
    mon[mon.unit.isin(show)].set_index(['unit','date_start'])[cols].round(3).to_excel(xl, 'by_month')
pd.set_option('display.width', 250)
print(out.round(2).to_string())
