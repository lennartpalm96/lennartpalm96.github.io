"""Infer the number of sampled conversations behind each province's published shares.
Published shares are counts / N rounded to 2 decimals; for small N only one N makes all shares integer counts.
Fitted on request-category shares (major level); large provinces (no unique fit) get usage_pct x Korean total.
Also returns conversations per province x SOC major group (Apr+May). These are estimates, not published figures.
Usage: python3 inferred_sample_sizes.py <aei_csv> <outdir>
"""
import sys, numpy as np, pandas as pd
aei_csv, outdir = sys.argv[1:3]
NAMES = {'KR-11':'Seoul','KR-26':'Busan','KR-27':'Daegu','KR-28':'Incheon','KR-29':'Gwangju','KR-30':'Daejeon','KR-31':'Ulsan',
         'KR-50':'Sejong','KR-41':'Gyeonggi','KR-42':'Gangwon','KR-43':'Chungbuk','KR-44':'Chungnam','KR-45':'Jeonbuk',
         'KR-46':'Jeonnam','KR-47':'Gyeongbuk','KR-48':'Gyeongnam','KR-49':'Jeju'}
d = pd.read_csv(aei_csv); d = d[d.geo_id.isin(NAMES)]
def fitN(v, Nmax=4000):
    v = np.asarray(v)/100; Ns = np.arange(30, Nmax)
    X = np.outer(Ns, v); err = np.abs(X - np.round(X)); tol = (0.00005*Ns + 0.002)[:, None]
    ok = (err <= tol).all(1); return int(Ns[ok][0]) if ok.any() else np.nan
rows = []
for month in sorted(d.date_start.unique()):
    for g, n in NAMES.items():
        sub = d[(d.geo_id==g) & (d.date_start==month)]
        v = sub[(sub.category_name=='request') & (sub.hierarchy_level==2) & (sub.metric_id=='pct')].value
        u = sub[(sub.category_name=='overall') & (sub.metric_id=='usage_pct')].value.iloc[0]
        rows.append(dict(month=month, geo=g, region=n, usage_pct=u, N_fit=fitN(v)))
r = pd.DataFrame(rows)
NK = r.dropna().groupby('month').apply(lambda x: x.N_fit.sum()/(x.usage_pct.sum()/100), include_groups=False)
r['N_korea_implied'] = r.month.map(NK)
r['N'] = np.where(r.N_fit.notna(), r.N_fit, (r.usage_pct/100*r.N_korea_implied).round(-1))
r['N_source'] = np.where(r.N_fit.notna(), 'inferred from share granularity', 'usage_pct x implied Korean total')
soc = d[(d.category_name=='soc_occupation') & (d.hierarchy_level==1) & (d.metric_id=='pct')].merge(
      r[['month','geo','N']], left_on=['date_start','geo_id'], right_on=['month','geo'])
soc['conversations'] = soc.value/100*soc.N
cells = soc.groupby(['geo_id','node_name']).conversations.sum().unstack(0).rename(columns=NAMES).round(1)
with pd.ExcelWriter(f'{outdir}/inferred_sample_sizes.xlsx') as xl:
    pd.DataFrame({'note': [__doc__]}).to_excel(xl, 'README', index=False)
    r.to_excel(xl, 'by_province_month', index=False)
    r.pivot(index='region', columns='month', values='N').assign(total=lambda x: x.sum(1)).sort_values('total', ascending=False).to_excel(xl, 'by_province')
    cells.to_excel(xl, 'province_x_soc_conversations')
print('Implied Korean sample per month:', NK.round(0).to_dict())
