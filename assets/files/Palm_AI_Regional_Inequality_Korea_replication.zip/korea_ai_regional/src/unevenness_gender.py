"""Core questions: (1) spatial unevenness of Claude usage, (2) occupational adjustment, (3) gender channel.

Regional units: Capital Area (Seoul+Incheon+Gyeonggi) + 14 other provinces (15 units).
AEI: release 2026-06-26, Apr+May 2026 average. Survey: Regional Employment Survey H2 2025 (시도가중값),
KSCO-8 2-digit -> SOC major via first-guess crosswalk. Region of employment = workplace.

Gender: the AEI has no user gender. Two exercises:
  (a) occupational channel: national usage per worker by SOC group vs. the female share of that group;
      female share of occupation-predicted usage.
  (b) sensitivity: re-weight the equal-intensity benchmark so a woman counts g of a man within each occupation
      (g from external surveys), and see how the Capital Area residual changes.
Usage: python3 unevenness_gender.py <aei_dir> <wage_dir> <crosswalk_csv> <out_xlsx>
"""
import sys, pandas as pd, numpy as np
aei_dir, wage_dir, xw_path, out = sys.argv[1:5]
AEI2REG = {'KR-11':'11','KR-26':'21','KR-27':'22','KR-28':'23','KR-29':'24','KR-30':'25','KR-31':'26','KR-50':'29',
           'KR-41':'31','KR-42':'32','KR-43':'33','KR-44':'34','KR-45':'35','KR-46':'36','KR-47':'37','KR-48':'38','KR-49':'39'}
NAME = {'11':'Seoul','21':'Busan','22':'Daegu','23':'Incheon','24':'Gwangju','25':'Daejeon','26':'Ulsan','29':'Sejong',
        '31':'Gyeonggi','32':'Gangwon','33':'Chungbuk','34':'Chungnam','35':'Jeonbuk','36':'Jeonnam','37':'Gyeongbuk',
        '38':'Gyeongnam','39':'Jeju'}
UNIT = {k: ('Capital Area' if k in {'11','23','31'} else v) for k, v in NAME.items()}
UNITS = ['Capital Area'] + [v for k, v in NAME.items() if k not in {'11','23','31'}]

# ---------- AEI ----------
d = pd.read_csv(f'{aei_dir}/aei_claude_ai_2026-06-26.csv')
d = d[d.geo_id.isin(list(AEI2REG) + ['KOR'])]
usage_prov = d[(d.category_name=='overall')&(d.metric_id=='usage_pct')&(d.geo_id!='KOR')].groupby('geo_id').value.mean()
usage = usage_prov.groupby(lambda g: UNIT[AEI2REG[g]]).sum().reindex(UNITS)
lab = d[(d.category_name=='soc_occupation')&(d.hierarchy_level==1)][['node_external_id','node_name']].drop_duplicates()
SOC = dict(zip(lab.node_name, lab.node_external_id.str[:2])); SOCNAME = {v:k for k,v in SOC.items()}
kor = (d[(d.geo_id=='KOR')&(d.category_name=='soc_occupation')&(d.hierarchy_level==1)&(d.metric_id=='pct')]
       .assign(soc=lambda x: x.node_name.map(SOC)).groupby('soc').value.mean())

# ---------- survey ----------
m = pd.read_pickle(f'{wage_dir}/micro.pkl')
m['w'] = m['시도가중값'].astype(float)
m['age'] = pd.to_numeric(m['만연령'], errors='coerce')
m['female'] = m['성별코드'] == '2'
m['unit_work'] = m['사업체직장소재지_행정구역코드'].map(UNIT)
m['unit_res'] = m['2자리_행정구역시도코드'].map(UNIT)
e = m[m['경제활동구분코드']=='1']
xw = pd.read_csv(xw_path, dtype={'ksco8_2d':str,'soc_major_1':str,'soc_major_2':str})
alloc = pd.concat([xw[['ksco8_2d','soc_major_1','weight_1']].set_axis(['ksco','soc','a'],axis=1),
                   xw[['ksco8_2d','soc_major_2','weight_2']].set_axis(['ksco','soc','a'],axis=1)]).dropna()
g = e.groupby(['unit_work','female','2자리_8차직업중분류코드']).w.sum().reset_index()
g.columns = ['unit','female','ksco','emp']
g = g.merge(alloc, on='ksco'); g['emp'] *= g.a
E = g.groupby(['unit','female','soc']).emp.sum()                     # unit x gender x soc
Es = E.groupby(['unit','soc']).sum().unstack().reindex(UNITS).fillna(0)

# ---------- (1) unevenness ----------
emp_share = 100 * Es.sum(1) / Es.values.sum()
pop = m[m.age.between(15,64)].groupby('unit_res').w.sum().reindex(UNITS); pop_share = 100*pop/pop.sum()
P = Es.div(Es.sum()).mul(kor.reindex(Es.columns)).sum(1)          # occupation-adjusted benchmark (% of usage)
diss = lambda a, b: 0.5 * (a - b).abs().sum()
uneven = pd.DataFrame({'usage_share': usage, 'pop15_64_share': pop_share, 'employment_share': emp_share,
                       'occupation_adjusted_benchmark': P})
uneven['usage_per_capita_index'] = uneven.usage_share / uneven.pop15_64_share
uneven['usage_per_worker_index'] = uneven.usage_share / uneven.employment_share
uneven['occupation_adjusted_index'] = uneven.usage_share / uneven.occupation_adjusted_benchmark
summary = pd.Series({
    'Dissimilarity: usage vs population 15-64 (%)': diss(usage, pop_share),
    'Dissimilarity: usage vs employment (%)': diss(usage, emp_share),
    'Dissimilarity: usage vs occupation-adjusted benchmark (%)': diss(usage, P),
    'Share of unevenness (vs employment) remaining after occupation adjustment': diss(usage, P) / diss(usage, emp_share),
    'Capital Area: log excess vs employment': np.log(usage['Capital Area']/emp_share['Capital Area']),
    'Capital Area: of which occupational composition': np.log(P['Capital Area']/emp_share['Capital Area']),
    'Capital Area: of which within-occupation intensity': np.log(usage['Capital Area']/P['Capital Area'])})

# ---------- (2)/(3) gender ----------
nat = E.groupby(['soc','female']).sum().unstack()
nat.columns = ['male','female']
occ = pd.DataFrame({'soc_label': [SOCNAME[s] for s in nat.index],
                    'employment_share': 100*nat.sum(1)/nat.values.sum(),
                    'female_share_of_occupation': 100*nat.female/nat.sum(1),
                    'usage_share': kor.reindex(nat.index)}, index=nat.index)
occ['usage_per_worker_index'] = occ.usage_share / occ.employment_share
wcorr = lambda x, y, w: np.cov(x, y, aweights=w)[0,1] / np.sqrt(np.cov(x, x, aweights=w)[0,0]*np.cov(y, y, aweights=w)[0,0])
pw = occ.usage_per_worker_index
fem_pred_usage = (pw * nat.female / nat.sum(1) * occ.usage_share).sum() / occ.usage_share.sum() * 100  # = sum_s U_s * f_s
gender_tab = pd.Series({
    'Female share of employment (%)': 100*nat.female.sum()/nat.values.sum(),
    'Female share of occupation-predicted usage (%)': (occ.usage_share * occ.female_share_of_occupation/100).sum() / occ.usage_share.sum() * 100,
    'Employment-weighted corr(female share, log usage per worker)': wcorr(occ.female_share_of_occupation, np.log(pw), occ.employment_share),
    'Usage-weighted mean female share of occupation (%)': np.average(occ.female_share_of_occupation, weights=occ.usage_share),
    'Employment-weighted mean female share of occupation (%)': np.average(occ.female_share_of_occupation, weights=occ.employment_share)})

# regional female concentration
fe = E.groupby(['unit','female']).sum().unstack(); fe.columns = ['male','female']
popf = m[m.age.between(15,64)].groupby(['unit_res','female']).w.sum().unstack(); popf.columns = ['male','female']
reg_gender = pd.DataFrame({'female_share_employment': 100*fe.female/fe.sum(1),
                           'female_share_pop15_64': 100*popf.female/popf.sum(1)}).reindex(UNITS)
cap_vs_rest = pd.DataFrame({
    'female employment in Capital Area / all female employment': [100*fe.female['Capital Area']/fe.female.sum()],
    'male employment in Capital Area / all male employment': [100*fe.male['Capital Area']/fe.male.sum()]})

# sensitivity: within-occupation gender gap g (woman = g x man)
sens = []
for label, gval in [('no gap', 1.0), ('BOK 2025 survey: 47.7/55.1', 47.7/55.1), ('Claude user share 31.2% women (global)', None)]:
    if gval is None:
        # women 31.2% of Claude users vs ~female share of internet-using adults ~50%: g = (31.2/68.8)
        gval = 31.2/68.8
    Eg = (E.xs(False, level='female').unstack().reindex(UNITS).fillna(0)
          + gval * E.xs(True, level='female').unstack().reindex(UNITS).fillna(0))
    Pg = Eg.div(Eg.sum()).mul(kor.reindex(Eg.columns)).sum(1)
    sens.append({'scenario': label, 'g (woman relative to man)': gval,
                 'Capital Area benchmark share': Pg['Capital Area'],
                 'Capital Area residual intensity': usage['Capital Area']/Pg['Capital Area'],
                 'Rest of Korea residual intensity': usage.drop('Capital Area').sum()/Pg.drop('Capital Area').sum()})
sens = pd.DataFrame(sens)

with pd.ExcelWriter(out) as xl:
    summary.round(3).to_frame('value').to_excel(xl, '1_unevenness_summary')
    uneven.round(3).to_excel(xl, '1_unevenness_by_region')
    occ.sort_values('usage_per_worker_index', ascending=False).round(2).to_excel(xl, '2_occupations_gender')
    gender_tab.round(3).to_frame('value').to_excel(xl, '3_gender_summary')
    reg_gender.round(2).to_excel(xl, '3_regional_female_share')
    cap_vs_rest.round(2).to_excel(xl, '3_capital_concentration', index=False)
    sens.round(3).to_excel(xl, '3_gender_sensitivity', index=False)

pd.set_option('display.width', 250)
print(summary.round(3).to_string()); print(uneven.round(2).to_string())
print(occ.sort_values('usage_per_worker_index', ascending=False).round(2).to_string())
print(gender_tab.round(3).to_string()); print(reg_gender.round(1).to_string()); print(cap_vs_rest.round(1).to_string())
print(sens.round(3).to_string())
