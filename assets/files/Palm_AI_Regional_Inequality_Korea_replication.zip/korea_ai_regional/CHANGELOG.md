# Changelog — korea_ai_regional

## 2026-11-02 — Figure 2 is now a map (`src/korea_map.py`)

- New script `src/korea_map.py <macro|province>` draws a choropleth of work use of Claude per worker
  (share of Korean work usage ÷ share of employment, by workplace), binned sequential blue scale, 1 = national rate.
  - `macro`: the four macro regions; Gangwon and Jeju in grey. This is paper Figure 2
    (`output/main/paper_figures/fig2_map_work_use_per_worker.png`, replacing `fig2_work_use_per_worker.png`).
  - `province`: provinces with Seoul, Incheon and Gyeonggi merged into the Capital Area, written to
    `output/additional/provinces_capital_area/provinces_map_work_usage_per_worker.png`.
- Values come from `macro_figure_data.xlsx` and `provinces_figure_data.xlsx` (column `work_usage_per_worker`); no numbers changed.
  The bar-chart version is still written as `output/main/macro_1_work_usage_per_worker.png`.
- New input `data/raw/geo/skorea-provinces-2018-geo.json`: Statistics Korea 2018 province boundaries, via
  github.com/southkorea/southkorea-maps. Ulleungdo is dropped from the drawing.
- New dependency: `shapely>=2.0` (polygon unions for the merged regions).
- `run_all.py`: new step 3b; stops with a pointer to MDIS if the survey microdata are missing.
- README: reason for excluding Gangwon and Jeju from the macro comparisons (thin survey cells for within-occupation
  comparisons: Jeju 1,973 wage earners, 28 of 52 occupation cells below 30; Gangwon 16 of 56 below 30; at most 7 per macro region).
- Paper: Figure 2 and its caption replaced; the exclusion of Gangwon and Jeju explained in the caption and in Data and methods.
- New variant `korea_ai_regional_no_microdata.zip`: identical, without `res_2025h2_microdata.csv`;
  `data/raw/res/DOWNLOAD_MICRODATA.md` explains how to get it from MDIS. The codebook is included.

## 2026-11-01 — Fix: SOC-level Capital Area wage premia (`src/regional_wage_premia.py`)

### Summary

Removed the redundant SOC major-group main effects from the specification that estimates the
Capital Area wage premium within each SOC group (section 4 of the script). The old specification was
rank-deficient, and the redundant terms shifted the premia for SOC groups that receive split KSCO codes.

### What changed

```diff
- f4 = f'lhw ~ C(soc) + C(soc):cap + C(occ) + {X}'
+ # identification: KSCO occupation FE + SOC-specific capital premium (rest of Korea pooled as reference).
+ # No separate C(soc) main effects: they are collinear with the occupation FE except through the duplicated rows of
+ # KSCO codes split across SOC groups, where they would be identified only from that artificial duplication.
+ f4 = f'lhw ~ C(soc):cap + C(occ) + {X}'
```

`X` (unchanged) = sex, age, age², education, marital status, tenure, tenure², firm size, temporary/daily status,
fixed-term contract, industry FE (KSIC-11 two-digit). Weights `시도가중값`; SEs clustered by household.

### Why

- Workers are assigned to SOC groups through the KSCO-8 → SOC crosswalk. Most KSCO codes map to a single SOC group,
  so `C(soc)` is a linear combination of the `C(occ)` dummies.
- About ten KSCO codes are split across two SOC groups (e.g. KSCO 31: 60% Business and Financial, 40% Office and
  Administrative). Their workers enter the regression twice, once per SOC group, with weights `w × share`. The two
  copies have identical wages and covariates and differ only in the SOC label.
- With `C(soc)` included, the SOC main effects are pinned down only through these duplicated rows. The design matrix
  is rank-deficient (rank 90 of 101 columns); statsmodels' pseudo-inverse returns one arbitrary solution, which
  feeds into the `C(soc):cap` interactions of the affected groups.
- Without `C(soc)`, the model is full rank (80 of 80 columns), and each interaction is the Capital Area premium within
  that SOC group, net of KSCO occupation FE and controls.

### Effect on results (`capital_premium_by_SOC` sheet)

Capital Area hourly-wage premium within SOC group, full controls, in %:

| SOC group | Old | New | Change (pp) | New 95% CI |
|---|---|---|---|---|
| Computer and Mathematical | 15.1 | 13.8 | −1.3 | 11.6 – 16.0 |
| Legal | 14.1 | 11.7 | −2.5 | 5.5 – 18.1 |
| Personal Care and Service | 6.8 | 6.0 | −0.8 | 4.2 – 7.8 |
| Healthcare Support | 3.7 | 4.2 | +0.5 | 2.3 – 6.0 |
| Business and Financial Operations | 7.2 | 6.8 | −0.4 | 5.6 – 7.9 |
| Protective Service | 1.1 | 1.5 | +0.4 | 0.3 – 2.7 |
| Architecture and Engineering | 12.1 | 12.4 | +0.3 | 10.7 – 14.2 |
| Food Preparation and Serving | 5.5 | 5.1 | −0.3 | 3.9 – 6.4 |
| Installation, Maintenance, and Repair | 4.1 | 3.8 | −0.3 | 1.8 – 5.9 |
| All other groups (no split KSCO codes) | | | ±0.2 or less | |

- The ranking is essentially unchanged: Computer and Mathematical still has the largest Capital Area premium.
- The correlation across SOC groups between the Capital Area wage premium and the log Capital-vs-rest AI usage
  ratio is −0.64 (17 groups with unsuppressed cells), against −0.63 before.

### Not affected

- **The paper.** Its within-occupation wage and degree-share gaps (Figure 4; "94–97% of the SMA level") come from
  `make_figures.py`, which regresses on region dummies and KSCO-8 occupation FE only. That model never contained
  SOC main effects.
- Regional premia in `regional_wage_premia.py` sections 1–3 (raw, occupation FE, full controls) — sheets
  `premia_vs_capital_pct` and `premia_long`.
- All AI usage, occupation-intensity, student, sophistication and GRDP results.

### How to verify

```bash
python run_all.py
```

Then open `output/additional/provinces_capital_area/regional_wage_premia.xlsx`, sheet `capital_premium_by_SOC`.
To reproduce the old numbers for comparison, temporarily restore `C(soc) +` in `f4`. statsmodels will again
report a rank-deficient design.
