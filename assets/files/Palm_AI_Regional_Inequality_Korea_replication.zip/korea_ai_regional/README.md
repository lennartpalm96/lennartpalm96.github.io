# AI Adoption as a New Frontier of Regional Inequality in Korea — replication package

Reproduces every figure and table in the paper and writes additional province-level results.

> **The Regional Employment Survey microdata are not included.** Download them from MDIS
> (https://mdis.kostat.go.kr) and save them as `data/raw/res/res_2025h2_microdata.csv` before running;
> see `data/raw/res/DOWNLOAD_MICRODATA.md`. All other data are included.

## Quick start

```bash
python -m pip install -r requirements.txt     # Python 3.10+
python run_all.py                             # ~3 minutes
```

The first run reads the survey microdata (CP949 CSV) once and caches it in `data/interim/micro.pkl`.
Use `python run_all.py --force-prepare` to rebuild that cache.

## Folder structure

```
data/raw/
  aei/      aei_claude_ai_2026-06-26.csv     Anthropic Economic Index, release 2026-06-26 (Claude.ai), + AEI_README.md
  res/      res_2025h2_microdata.csv         NOT INCLUDED: Regional Employment Survey, H2 2025 (Oct 2025), C-type microdata;
                                             download from MDIS, see res/DOWNLOAD_MICRODATA.md
            res_2025h2_codebook.xlsx         its item and code book
  kedi/     Korea_2025_Student_Enrollment.csv + Korea_2025_Data_Construction.md   KEDI enrollment, 1 Apr 2025
  kosis/    grdp_nominal_real_2000_2024.xlsx  KOSIS DT_1C91 (Regional Income), nominal + chained real
            population_2000_2025.xlsx         KOSIS DT_1B040A3 (resident registration, year-end)
  geo/      skorea-provinces-2018-geo.json    province boundaries, Statistics Korea 2018 (via github.com/southkorea/southkorea-maps)
src/        one script per analysis step (each documents its method in the header)
run_all.py  runs everything in order
output/     created by run_all.py (see below)
```

## Outputs

| Folder | Contents |
|---|---|
| `output/main/paper_figures/` | Figures 1–6 of the paper, named as in the text |
| `output/main/` | Macro-region figures (incl. worker age, usage sophistication) and the tables behind them: `macro_figure_data.xlsx`, `macro_sophistication_data.xlsx`, `sma_grdp_2000_2024.xlsx` |
| `output/crosswalk/` | KSCO-8 2-digit → SOC major crosswalk (judgment-based, with confidence flags) and implied SOC employment |
| `output/additional/provinces_17/` | All 17 provinces, no aggregation (reference: Seoul): the 7 figures + data, region × occupation usage intensity (workplace and residence benchmarks), usage by use case, coursework per student |
| `output/additional/provinces_capital_area/` | 15 units with Seoul + Incheon + Gyeonggi merged: the 7 figures + data, all intensity results, regional wage premia (raw / occupation FE / full controls; Capital Area premium by SOC group), unevenness and gender analysis |
| `output/additional/data_checks/` | Inferred conversation counts per province and per province × occupation cell; composition of Computer & Mathematical usage |

## Pipeline (`run_all.py`)

| Step | Script | What it does |
|---|---|---|
| 0 | `00_prepare.py` | Survey CSV → pickle cache |
| 1 | `build_crosswalk.py` | KSCO-8 → SOC crosswalk; weighted employment by code |
| 2 | `sma_grdp_analysis.py` | SMA share of GRDP and population, growth by region, counterfactuals (Figure 1) |
| 3 | `make_figures.py <macro\|province\|province17>` | Work use per worker; occupation adjustment; within-occupation intensity; gaps in AI use vs wages, degree share and age; coursework per student (Figures 3–6; the bar-chart version of Figure 2) |
| 3 | `korea_map.py <macro\|province>` | Map of work use per worker: macro regions (Figure 2); provinces with the Capital Area merged (additional results) |
| 3 | `sophistication.py <mode>` | AI autonomy, task education, task length, speed-up, automation, technical outputs, multitasking |
| 4 | `usage_by_region_occupation.py` | Province × occupation observed usage, benchmark and intensity |
| 4 | `usage_by_use_case.py` | Work / personal / coursework usage vs employment, population, students |
| 4 | `student_intensity.py` | Coursework per student: three enrollment bases |
| 4 | `capital_area_analysis.py` | All of the above with the Capital Area merged |
| 4 | `regional_wage_premia.py` | WLS of log hourly wages; Capital Area premium by SOC group |
| 4 | `unevenness_gender.py` | Dissimilarity indices, occupational decomposition, gender sensitivity |
| 5 | `inferred_sample_sizes.py`, `cm_breakdown.py` | Data checks |

## Key definitions

- **Region of employment** = workplace province (`사업체직장소재지_행정구역코드`); survey weights `시도가중값`.
- **Occupation-adjusted index** = region's usage share ÷ the share expected if it used each SOC group's tasks at the national rate given its employment in that group (1 = national rate).
- **Macro regions**: SMA = Seoul, Incheon, Gyeonggi; Chungcheong = Chungbuk, Chungnam, Daejeon, Sejong; Jeolla = Jeonbuk, Jeonnam, Gwangju; Gyeongsang = Gyeongbuk, Gyeongnam, Busan, Ulsan, Daegu. Gangwon and Jeju are excluded from macro charts but kept in national totals: each is a single province with a thin survey sample for within-occupation comparisons (Jeju: 1,973 wage earners, 28 of 52 occupation cells below 30; Gangwon: 16 of 56 cells below 30, against at most 7 in each macro region). They are shown in all province-level results.
- AEI values are averages of April and May 2026.

## Data notes

- Anthropic Economic Index data are released under CC-BY.
- The Regional Employment Survey microdata are distributed by Statistics Korea through MDIS and are not redistributed here; the codebook is included.
- AEI locations come from IP addresses; province-level assignment within the capital region is imprecise, which is why the paper reports the SMA as one unit.
